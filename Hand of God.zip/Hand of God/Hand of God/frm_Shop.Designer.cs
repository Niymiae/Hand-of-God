﻿namespace HandofGod
{
    partial class frm_Shop
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.prop0 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.prop1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.btnfind_prop0 = new System.Windows.Forms.Button();
            this.btnfind_prop1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnfind_prop6 = new System.Windows.Forms.Button();
            this.prop6 = new System.Windows.Forms.NumericUpDown();
            this.btnfind_prop5 = new System.Windows.Forms.Button();
            this.prop5 = new System.Windows.Forms.NumericUpDown();
            this.btnfind_prop4 = new System.Windows.Forms.Button();
            this.prop4 = new System.Windows.Forms.NumericUpDown();
            this.btnfind_prop3 = new System.Windows.Forms.Button();
            this.prop3 = new System.Windows.Forms.NumericUpDown();
            this.btnfind_prop2 = new System.Windows.Forms.Button();
            this.prop2 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.prop11 = new System.Windows.Forms.ComboBox();
            this.prop10 = new System.Windows.Forms.ComboBox();
            this.prop9 = new System.Windows.Forms.ComboBox();
            this.prop8 = new System.Windows.Forms.ComboBox();
            this.prop7 = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.spin_mul_sell = new System.Windows.Forms.NumericUpDown();
            this.spin_mul_buy = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.prop13 = new System.Windows.Forms.ComboBox();
            this.prop12 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.prop17 = new System.Windows.Forms.NumericUpDown();
            this.prop16 = new System.Windows.Forms.NumericUpDown();
            this.prop15 = new System.Windows.Forms.NumericUpDown();
            this.prop14 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.speech6 = new HandofGod.MudlikeRichTextBox();
            this.speech5 = new HandofGod.MudlikeRichTextBox();
            this.speech4 = new HandofGod.MudlikeRichTextBox();
            this.speech3 = new HandofGod.MudlikeRichTextBox();
            this.speech2 = new HandofGod.MudlikeRichTextBox();
            this.speech1 = new HandofGod.MudlikeRichTextBox();
            this.speech0 = new HandofGod.MudlikeRichTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.spin_vnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prop6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spin_mul_sell)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_mul_buy)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prop17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop14)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // prop0
            // 
            this.prop0.Location = new System.Drawing.Point(214, 17);
            this.prop0.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop0.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop0.Name = "prop0";
            this.prop0.Size = new System.Drawing.Size(88, 20);
            this.prop0.TabIndex = 1;
            this.prop0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(169, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 81;
            this.label2.Text = "Mob: ";
            // 
            // prop1
            // 
            this.prop1.Location = new System.Drawing.Point(412, 17);
            this.prop1.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop1.Name = "prop1";
            this.prop1.Size = new System.Drawing.Size(88, 20);
            this.prop1.TabIndex = 3;
            this.prop1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(367, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 83;
            this.label3.Text = "Stanza: ";
            // 
            // btnfind_prop0
            // 
            this.btnfind_prop0.Location = new System.Drawing.Point(308, 14);
            this.btnfind_prop0.Name = "btnfind_prop0";
            this.btnfind_prop0.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop0.TabIndex = 2;
            this.btnfind_prop0.TabStop = false;
            this.btnfind_prop0.Text = "Trova";
            this.btnfind_prop0.UseVisualStyleBackColor = true;
            this.btnfind_prop0.Click += new System.EventHandler(this.findelementclick);
            // 
            // btnfind_prop1
            // 
            this.btnfind_prop1.Location = new System.Drawing.Point(506, 14);
            this.btnfind_prop1.Name = "btnfind_prop1";
            this.btnfind_prop1.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop1.TabIndex = 4;
            this.btnfind_prop1.TabStop = false;
            this.btnfind_prop1.Text = "Trova";
            this.btnfind_prop1.UseVisualStyleBackColor = true;
            this.btnfind_prop1.Click += new System.EventHandler(this.findelementclick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnfind_prop6);
            this.groupBox1.Controls.Add(this.prop6);
            this.groupBox1.Controls.Add(this.btnfind_prop5);
            this.groupBox1.Controls.Add(this.prop5);
            this.groupBox1.Controls.Add(this.btnfind_prop4);
            this.groupBox1.Controls.Add(this.prop4);
            this.groupBox1.Controls.Add(this.btnfind_prop3);
            this.groupBox1.Controls.Add(this.prop3);
            this.groupBox1.Controls.Add(this.btnfind_prop2);
            this.groupBox1.Controls.Add(this.prop2);
            this.groupBox1.Location = new System.Drawing.Point(12, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(170, 150);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oggetti venduti";
            // 
            // btnfind_prop6
            // 
            this.btnfind_prop6.Location = new System.Drawing.Point(111, 120);
            this.btnfind_prop6.Name = "btnfind_prop6";
            this.btnfind_prop6.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop6.TabIndex = 14;
            this.btnfind_prop6.TabStop = false;
            this.btnfind_prop6.Text = "Trova";
            this.btnfind_prop6.UseVisualStyleBackColor = true;
            this.btnfind_prop6.Click += new System.EventHandler(this.findelementclick);
            // 
            // prop6
            // 
            this.prop6.Location = new System.Drawing.Point(6, 123);
            this.prop6.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop6.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop6.Name = "prop6";
            this.prop6.Size = new System.Drawing.Size(88, 20);
            this.prop6.TabIndex = 13;
            this.prop6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // btnfind_prop5
            // 
            this.btnfind_prop5.Location = new System.Drawing.Point(111, 94);
            this.btnfind_prop5.Name = "btnfind_prop5";
            this.btnfind_prop5.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop5.TabIndex = 12;
            this.btnfind_prop5.TabStop = false;
            this.btnfind_prop5.Text = "Trova";
            this.btnfind_prop5.UseVisualStyleBackColor = true;
            this.btnfind_prop5.Click += new System.EventHandler(this.findelementclick);
            // 
            // prop5
            // 
            this.prop5.Location = new System.Drawing.Point(6, 97);
            this.prop5.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop5.Name = "prop5";
            this.prop5.Size = new System.Drawing.Size(88, 20);
            this.prop5.TabIndex = 11;
            this.prop5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // btnfind_prop4
            // 
            this.btnfind_prop4.Location = new System.Drawing.Point(111, 68);
            this.btnfind_prop4.Name = "btnfind_prop4";
            this.btnfind_prop4.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop4.TabIndex = 10;
            this.btnfind_prop4.TabStop = false;
            this.btnfind_prop4.Text = "Trova";
            this.btnfind_prop4.UseVisualStyleBackColor = true;
            this.btnfind_prop4.Click += new System.EventHandler(this.findelementclick);
            // 
            // prop4
            // 
            this.prop4.Location = new System.Drawing.Point(6, 71);
            this.prop4.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop4.Name = "prop4";
            this.prop4.Size = new System.Drawing.Size(88, 20);
            this.prop4.TabIndex = 9;
            this.prop4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // btnfind_prop3
            // 
            this.btnfind_prop3.Location = new System.Drawing.Point(111, 42);
            this.btnfind_prop3.Name = "btnfind_prop3";
            this.btnfind_prop3.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop3.TabIndex = 8;
            this.btnfind_prop3.TabStop = false;
            this.btnfind_prop3.Text = "Trova";
            this.btnfind_prop3.UseVisualStyleBackColor = true;
            this.btnfind_prop3.Click += new System.EventHandler(this.findelementclick);
            // 
            // prop3
            // 
            this.prop3.Location = new System.Drawing.Point(6, 45);
            this.prop3.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop3.Name = "prop3";
            this.prop3.Size = new System.Drawing.Size(88, 20);
            this.prop3.TabIndex = 7;
            this.prop3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // btnfind_prop2
            // 
            this.btnfind_prop2.Location = new System.Drawing.Point(111, 16);
            this.btnfind_prop2.Name = "btnfind_prop2";
            this.btnfind_prop2.Size = new System.Drawing.Size(45, 23);
            this.btnfind_prop2.TabIndex = 6;
            this.btnfind_prop2.TabStop = false;
            this.btnfind_prop2.Text = "Trova";
            this.btnfind_prop2.UseVisualStyleBackColor = true;
            this.btnfind_prop2.Click += new System.EventHandler(this.findelementclick);
            // 
            // prop2
            // 
            this.prop2.Location = new System.Drawing.Point(6, 19);
            this.prop2.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.prop2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.prop2.Name = "prop2";
            this.prop2.Size = new System.Drawing.Size(88, 20);
            this.prop2.TabIndex = 5;
            this.prop2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.prop11);
            this.groupBox2.Controls.Add(this.prop10);
            this.groupBox2.Controls.Add(this.prop9);
            this.groupBox2.Controls.Add(this.prop8);
            this.groupBox2.Controls.Add(this.prop7);
            this.groupBox2.Location = new System.Drawing.Point(188, 59);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 150);
            this.groupBox2.TabIndex = 90;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tipi di oggetti acquistati";
            // 
            // prop11
            // 
            this.prop11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.prop11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop11.FormattingEnabled = true;
            this.prop11.Location = new System.Drawing.Point(6, 122);
            this.prop11.Name = "prop11";
            this.prop11.Size = new System.Drawing.Size(237, 21);
            this.prop11.TabIndex = 19;
            this.prop11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop10
            // 
            this.prop10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.prop10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop10.FormattingEnabled = true;
            this.prop10.Location = new System.Drawing.Point(6, 96);
            this.prop10.Name = "prop10";
            this.prop10.Size = new System.Drawing.Size(237, 21);
            this.prop10.TabIndex = 18;
            this.prop10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop9
            // 
            this.prop9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.prop9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop9.FormattingEnabled = true;
            this.prop9.Location = new System.Drawing.Point(6, 70);
            this.prop9.Name = "prop9";
            this.prop9.Size = new System.Drawing.Size(237, 21);
            this.prop9.TabIndex = 17;
            this.prop9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop8
            // 
            this.prop8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.prop8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop8.FormattingEnabled = true;
            this.prop8.Location = new System.Drawing.Point(6, 44);
            this.prop8.Name = "prop8";
            this.prop8.Size = new System.Drawing.Size(237, 21);
            this.prop8.TabIndex = 16;
            this.prop8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop7
            // 
            this.prop7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.prop7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop7.FormattingEnabled = true;
            this.prop7.Location = new System.Drawing.Point(6, 18);
            this.prop7.Name = "prop7";
            this.prop7.Size = new System.Drawing.Size(237, 21);
            this.prop7.TabIndex = 15;
            this.prop7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.spin_mul_sell);
            this.groupBox3.Controls.Add(this.spin_mul_buy);
            this.groupBox3.Location = new System.Drawing.Point(449, 59);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(218, 65);
            this.groupBox3.TabIndex = 91;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Moltiplicatori";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Vendita: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Acquisto: ";
            // 
            // spin_mul_sell
            // 
            this.spin_mul_sell.DecimalPlaces = 2;
            this.spin_mul_sell.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.spin_mul_sell.Location = new System.Drawing.Point(79, 40);
            this.spin_mul_sell.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.spin_mul_sell.Name = "spin_mul_sell";
            this.spin_mul_sell.Size = new System.Drawing.Size(59, 20);
            this.spin_mul_sell.TabIndex = 21;
            this.spin_mul_sell.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // spin_mul_buy
            // 
            this.spin_mul_buy.DecimalPlaces = 2;
            this.spin_mul_buy.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.spin_mul_buy.Location = new System.Drawing.Point(79, 19);
            this.spin_mul_buy.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.spin_mul_buy.Name = "spin_mul_buy";
            this.spin_mul_buy.Size = new System.Drawing.Size(59, 20);
            this.spin_mul_buy.TabIndex = 20;
            this.spin_mul_buy.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.prop13);
            this.groupBox4.Controls.Add(this.prop12);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(450, 130);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(217, 79);
            this.groupBox4.TabIndex = 92;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Reazioni";
            // 
            // prop13
            // 
            this.prop13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop13.FormattingEnabled = true;
            this.prop13.Location = new System.Drawing.Point(78, 51);
            this.prop13.Name = "prop13";
            this.prop13.Size = new System.Drawing.Size(121, 21);
            this.prop13.TabIndex = 23;
            this.prop13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop12
            // 
            this.prop12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.prop12.FormattingEnabled = true;
            this.prop12.Location = new System.Drawing.Point(78, 25);
            this.prop12.Name = "prop12";
            this.prop12.Size = new System.Drawing.Size(121, 21);
            this.prop12.TabIndex = 22;
            this.prop12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Attacco: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Indigenza: ";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.prop17);
            this.groupBox5.Controls.Add(this.prop16);
            this.groupBox5.Controls.Add(this.prop15);
            this.groupBox5.Controls.Add(this.prop14);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Location = new System.Drawing.Point(12, 215);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(655, 81);
            this.groupBox5.TabIndex = 93;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Orari";
            // 
            // prop17
            // 
            this.prop17.Location = new System.Drawing.Point(247, 45);
            this.prop17.Maximum = new decimal(new int[] {
            300000,
            0,
            0,
            0});
            this.prop17.Name = "prop17";
            this.prop17.Size = new System.Drawing.Size(88, 20);
            this.prop17.TabIndex = 27;
            this.prop17.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop16
            // 
            this.prop16.Location = new System.Drawing.Point(247, 19);
            this.prop16.Maximum = new decimal(new int[] {
            300000,
            0,
            0,
            0});
            this.prop16.Name = "prop16";
            this.prop16.Size = new System.Drawing.Size(88, 20);
            this.prop16.TabIndex = 26;
            this.prop16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop15
            // 
            this.prop15.Location = new System.Drawing.Point(81, 45);
            this.prop15.Maximum = new decimal(new int[] {
            300000,
            0,
            0,
            0});
            this.prop15.Name = "prop15";
            this.prop15.Size = new System.Drawing.Size(88, 20);
            this.prop15.TabIndex = 25;
            this.prop15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // prop14
            // 
            this.prop14.Location = new System.Drawing.Point(81, 19);
            this.prop14.Maximum = new decimal(new int[] {
            300000,
            0,
            0,
            0});
            this.prop14.Name = "prop14";
            this.prop14.Size = new System.Drawing.Size(88, 20);
            this.prop14.TabIndex = 24;
            this.prop14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(179, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Chiusura 2: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(179, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Apertura 2: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Chiusura 1: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Apertura 1: ";
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.speech6);
            this.groupBox6.Controls.Add(this.speech5);
            this.groupBox6.Controls.Add(this.speech4);
            this.groupBox6.Controls.Add(this.speech3);
            this.groupBox6.Controls.Add(this.speech2);
            this.groupBox6.Controls.Add(this.speech1);
            this.groupBox6.Controls.Add(this.speech0);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Location = new System.Drawing.Point(12, 302);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(654, 204);
            this.groupBox6.TabIndex = 94;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Risposte";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(116, 172);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 13);
            this.label18.TabIndex = 14;
            this.label18.Text = "Compra: ";
            // 
            // speech6
            // 
            this.speech6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech6.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech6.DetectUrls = false;
            this.speech6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech6.Location = new System.Drawing.Point(171, 169);
            this.speech6.Multiline = false;
            this.speech6.Name = "speech6";
            this.speech6.Size = new System.Drawing.Size(477, 20);
            this.speech6.TabIndex = 34;
            this.speech6.Text = "";
            // 
            // speech5
            // 
            this.speech5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech5.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech5.DetectUrls = false;
            this.speech5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech5.Location = new System.Drawing.Point(171, 143);
            this.speech5.Multiline = false;
            this.speech5.Name = "speech5";
            this.speech5.Size = new System.Drawing.Size(477, 20);
            this.speech5.TabIndex = 33;
            this.speech5.Text = "";
            this.speech5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // speech4
            // 
            this.speech4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech4.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech4.DetectUrls = false;
            this.speech4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech4.Location = new System.Drawing.Point(171, 117);
            this.speech4.Multiline = false;
            this.speech4.Name = "speech4";
            this.speech4.Size = new System.Drawing.Size(477, 20);
            this.speech4.TabIndex = 32;
            this.speech4.Text = "";
            this.speech4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // speech3
            // 
            this.speech3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech3.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech3.DetectUrls = false;
            this.speech3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech3.Location = new System.Drawing.Point(171, 91);
            this.speech3.Multiline = false;
            this.speech3.Name = "speech3";
            this.speech3.Size = new System.Drawing.Size(477, 20);
            this.speech3.TabIndex = 31;
            this.speech3.Text = "";
            this.speech3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // speech2
            // 
            this.speech2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech2.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech2.DetectUrls = false;
            this.speech2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech2.Location = new System.Drawing.Point(171, 65);
            this.speech2.Multiline = false;
            this.speech2.Name = "speech2";
            this.speech2.Size = new System.Drawing.Size(477, 20);
            this.speech2.TabIndex = 30;
            this.speech2.Text = "";
            this.speech2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // speech1
            // 
            this.speech1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech1.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech1.DetectUrls = false;
            this.speech1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech1.Location = new System.Drawing.Point(171, 39);
            this.speech1.Multiline = false;
            this.speech1.Name = "speech1";
            this.speech1.Size = new System.Drawing.Size(477, 20);
            this.speech1.TabIndex = 29;
            this.speech1.Text = "";
            this.speech1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // speech0
            // 
            this.speech0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.speech0.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.speech0.DetectUrls = false;
            this.speech0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.speech0.Location = new System.Drawing.Point(171, 13);
            this.speech0.Multiline = false;
            this.speech0.Name = "speech0";
            this.speech0.Size = new System.Drawing.Size(477, 20);
            this.speech0.TabIndex = 28;
            this.speech0.Text = "";
            this.speech0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.speech6_KeyDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(121, 146);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Vende: ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(39, 120);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Il cliente non ha monete: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(18, 94);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Il negoziante non ha monete: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 42);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Il cliente non ha l\'oggetto: ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(94, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Non compra: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Il negoziante non ha l\'oggetto: ";
            // 
            // frm_Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 547);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnfind_prop1);
            this.Controls.Add(this.btnfind_prop0);
            this.Controls.Add(this.prop1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.prop0);
            this.Controls.Add(this.label2);
            this.Name = "frm_Shop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Controls.SetChildIndex(this.btnok, 0);
            this.Controls.SetChildIndex(this.btncancel, 0);
            this.Controls.SetChildIndex(this.btnnext, 0);
            this.Controls.SetChildIndex(this.btnprev, 0);
            this.Controls.SetChildIndex(this.btnrestore, 0);
            this.Controls.SetChildIndex(this.btnapply, 0);
            this.Controls.SetChildIndex(this.lblvnum, 0);
            this.Controls.SetChildIndex(this.spin_vnum, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.prop0, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.prop1, 0);
            this.Controls.SetChildIndex(this.btnfind_prop0, 0);
            this.Controls.SetChildIndex(this.btnfind_prop1, 0);
            this.Controls.SetChildIndex(this.groupBox1, 0);
            this.Controls.SetChildIndex(this.groupBox2, 0);
            this.Controls.SetChildIndex(this.groupBox3, 0);
            this.Controls.SetChildIndex(this.groupBox4, 0);
            this.Controls.SetChildIndex(this.groupBox5, 0);
            this.Controls.SetChildIndex(this.groupBox6, 0);
            ((System.ComponentModel.ISupportInitialize)(this.spin_vnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.prop6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spin_mul_sell)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_mul_buy)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prop17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prop14)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown prop0;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown prop1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnfind_prop0;
        private System.Windows.Forms.Button btnfind_prop1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnfind_prop6;
        private System.Windows.Forms.NumericUpDown prop6;
        private System.Windows.Forms.Button btnfind_prop5;
        private System.Windows.Forms.NumericUpDown prop5;
        private System.Windows.Forms.Button btnfind_prop4;
        private System.Windows.Forms.NumericUpDown prop4;
        private System.Windows.Forms.Button btnfind_prop3;
        private System.Windows.Forms.NumericUpDown prop3;
        private System.Windows.Forms.Button btnfind_prop2;
        private System.Windows.Forms.NumericUpDown prop2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox prop11;
        private System.Windows.Forms.ComboBox prop10;
        private System.Windows.Forms.ComboBox prop9;
        private System.Windows.Forms.ComboBox prop8;
        private System.Windows.Forms.ComboBox prop7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown spin_mul_sell;
        private System.Windows.Forms.NumericUpDown spin_mul_buy;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox prop13;
        private System.Windows.Forms.ComboBox prop12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown prop17;
        private System.Windows.Forms.NumericUpDown prop16;
        private System.Windows.Forms.NumericUpDown prop15;
        private System.Windows.Forms.NumericUpDown prop14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label18;
        private MudlikeRichTextBox speech6;
        private MudlikeRichTextBox speech5;
        private MudlikeRichTextBox speech4;
        private MudlikeRichTextBox speech3;
        private MudlikeRichTextBox speech2;
        private MudlikeRichTextBox speech1;
        private MudlikeRichTextBox speech0;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}