﻿namespace HandofGod
{
    partial class frm_MobDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnapply = new System.Windows.Forms.Button();
            this.btnrestore = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Afindnext = new System.Windows.Forms.Button();
            this.edt_Anext = new System.Windows.Forms.NumericUpDown();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.edt2_func_fail = new System.Windows.Forms.TextBox();
            this.edt1_func_fail = new System.Windows.Forms.TextBox();
            this.param2_func_fail = new System.Windows.Forms.Label();
            this.param1_func_fail = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.edt2_func_success = new System.Windows.Forms.TextBox();
            this.edt1_func_success = new System.Windows.Forms.TextBox();
            this.param2_func_success = new System.Windows.Forms.Label();
            this.param1_func_success = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.edt_type = new System.Windows.Forms.TextBox();
            this.edt_id = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.combo_Qnext = new System.Windows.Forms.ComboBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tab_text = new System.Windows.Forms.TabPage();
            this.tab_unspoken = new System.Windows.Forms.TabPage();
            this.tab_before_act = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.tab_after_act = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.tab_checks = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.roll9_failbtn = new System.Windows.Forms.Button();
            this.roll9_fail = new System.Windows.Forms.NumericUpDown();
            this.roll9_faillbl = new System.Windows.Forms.Label();
            this.roll8_failbtn = new System.Windows.Forms.Button();
            this.roll8_fail = new System.Windows.Forms.NumericUpDown();
            this.roll8_faillbl = new System.Windows.Forms.Label();
            this.roll7_failbtn = new System.Windows.Forms.Button();
            this.roll7_fail = new System.Windows.Forms.NumericUpDown();
            this.roll7_faillbl = new System.Windows.Forms.Label();
            this.roll6_failbtn = new System.Windows.Forms.Button();
            this.roll6_fail = new System.Windows.Forms.NumericUpDown();
            this.roll6_faillbl = new System.Windows.Forms.Label();
            this.roll5_failbtn = new System.Windows.Forms.Button();
            this.roll5_fail = new System.Windows.Forms.NumericUpDown();
            this.roll5_faillbl = new System.Windows.Forms.Label();
            this.roll4_failbtn = new System.Windows.Forms.Button();
            this.roll4_fail = new System.Windows.Forms.NumericUpDown();
            this.roll4_faillbl = new System.Windows.Forms.Label();
            this.roll3_failbtn = new System.Windows.Forms.Button();
            this.roll3_fail = new System.Windows.Forms.NumericUpDown();
            this.roll3_faillbl = new System.Windows.Forms.Label();
            this.roll2_failbtn = new System.Windows.Forms.Button();
            this.roll2_fail = new System.Windows.Forms.NumericUpDown();
            this.roll2_faillbl = new System.Windows.Forms.Label();
            this.roll1_failbtn = new System.Windows.Forms.Button();
            this.roll1_fail = new System.Windows.Forms.NumericUpDown();
            this.roll1_faillbl = new System.Windows.Forms.Label();
            this.roll0_failbtn = new System.Windows.Forms.Button();
            this.roll0_fail = new System.Windows.Forms.NumericUpDown();
            this.roll0_faillbl = new System.Windows.Forms.Label();
            this.roll9 = new System.Windows.Forms.CheckBox();
            this.roll9_val = new System.Windows.Forms.NumericUpDown();
            this.roll8 = new System.Windows.Forms.CheckBox();
            this.roll8_val = new System.Windows.Forms.NumericUpDown();
            this.roll7 = new System.Windows.Forms.CheckBox();
            this.roll7_val = new System.Windows.Forms.NumericUpDown();
            this.roll6 = new System.Windows.Forms.CheckBox();
            this.roll6_val = new System.Windows.Forms.NumericUpDown();
            this.roll5 = new System.Windows.Forms.CheckBox();
            this.roll5_val = new System.Windows.Forms.NumericUpDown();
            this.roll4 = new System.Windows.Forms.CheckBox();
            this.roll4_val = new System.Windows.Forms.NumericUpDown();
            this.roll3 = new System.Windows.Forms.CheckBox();
            this.roll3_val = new System.Windows.Forms.NumericUpDown();
            this.roll2 = new System.Windows.Forms.CheckBox();
            this.roll2_val = new System.Windows.Forms.NumericUpDown();
            this.roll1 = new System.Windows.Forms.CheckBox();
            this.roll1_val = new System.Windows.Forms.NumericUpDown();
            this.roll0 = new System.Windows.Forms.CheckBox();
            this.roll0_val = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.check9 = new System.Windows.Forms.CheckBox();
            this.check9_val = new System.Windows.Forms.NumericUpDown();
            this.check8 = new System.Windows.Forms.CheckBox();
            this.check8_val = new System.Windows.Forms.NumericUpDown();
            this.check7 = new System.Windows.Forms.CheckBox();
            this.check7_val = new System.Windows.Forms.NumericUpDown();
            this.check6 = new System.Windows.Forms.CheckBox();
            this.check6_val = new System.Windows.Forms.NumericUpDown();
            this.check5 = new System.Windows.Forms.CheckBox();
            this.check5_val = new System.Windows.Forms.NumericUpDown();
            this.check4 = new System.Windows.Forms.CheckBox();
            this.check4_val = new System.Windows.Forms.NumericUpDown();
            this.check3 = new System.Windows.Forms.CheckBox();
            this.check3_val = new System.Windows.Forms.NumericUpDown();
            this.check2 = new System.Windows.Forms.CheckBox();
            this.check2_val = new System.Windows.Forms.NumericUpDown();
            this.check1 = new System.Windows.Forms.CheckBox();
            this.check1_val = new System.Windows.Forms.NumericUpDown();
            this.check0 = new System.Windows.Forms.CheckBox();
            this.check0_val = new System.Windows.Forms.NumericUpDown();
            this.panel8 = new System.Windows.Forms.Panel();
            this.gaugecharcounter = new HandofGod.CharCounterProgressBar();
            this.desc0 = new HandofGod.MudlikeRichTextBox();
            this.desc1 = new HandofGod.MudlikeRichTextBox();
            this.desc4 = new HandofGod.MudlikeRichTextBox();
            this.desc3 = new HandofGod.MudlikeRichTextBox();
            this.desc2 = new HandofGod.MudlikeRichTextBox();
            this.desc7 = new HandofGod.MudlikeRichTextBox();
            this.desc6 = new HandofGod.MudlikeRichTextBox();
            this.desc5 = new HandofGod.MudlikeRichTextBox();
            this.func_fail = new HandofGod.ValAffEditbox();
            this.func_success = new HandofGod.ValAffEditbox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_Anext)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_id)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tab_text.SuspendLayout();
            this.tab_unspoken.SuspendLayout();
            this.tab_before_act.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tab_after_act.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tab_checks.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roll9_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll8_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll7_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll6_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll5_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll4_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll3_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll2_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll1_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll0_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll9_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll8_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll7_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll6_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll5_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll4_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll3_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll2_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll1_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll0_val)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.check9_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check8_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check7_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check6_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check5_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check4_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check3_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check2_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check1_val)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.check0_val)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.func_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.func_success)).BeginInit();
            this.SuspendLayout();
            // 
            // btnapply
            // 
            this.btnapply.Location = new System.Drawing.Point(580, 5);
            this.btnapply.Name = "btnapply";
            this.btnapply.Size = new System.Drawing.Size(75, 23);
            this.btnapply.TabIndex = 24;
            this.btnapply.Text = "Applica";
            this.btnapply.UseVisualStyleBackColor = true;
            this.btnapply.Click += new System.EventHandler(this.btnapply_Click);
            // 
            // btnrestore
            // 
            this.btnrestore.Location = new System.Drawing.Point(661, 5);
            this.btnrestore.Name = "btnrestore";
            this.btnrestore.Size = new System.Drawing.Size(75, 23);
            this.btnrestore.TabIndex = 23;
            this.btnrestore.Text = "Ripristina";
            this.btnrestore.UseVisualStyleBackColor = true;
            this.btnrestore.Click += new System.EventHandler(this.btnrestore_Click);
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(84, 5);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 22;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnok
            // 
            this.btnok.Location = new System.Drawing.Point(3, 5);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 23);
            this.btnok.TabIndex = 21;
            this.btnok.Text = "Ok";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_Afindnext);
            this.panel1.Controls.Add(this.edt_Anext);
            this.panel1.Controls.Add(this.groupBox12);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.edt_type);
            this.panel1.Controls.Add(this.edt_id);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.combo_Qnext);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(740, 93);
            this.panel1.TabIndex = 25;
            // 
            // btn_Afindnext
            // 
            this.btn_Afindnext.Location = new System.Drawing.Point(157, 63);
            this.btn_Afindnext.Name = "btn_Afindnext";
            this.btn_Afindnext.Size = new System.Drawing.Size(43, 20);
            this.btn_Afindnext.TabIndex = 50;
            this.btn_Afindnext.Text = "Trova";
            this.btn_Afindnext.UseVisualStyleBackColor = true;
            this.btn_Afindnext.Click += new System.EventHandler(this.btn_findnext_Click);
            // 
            // edt_Anext
            // 
            this.edt_Anext.Location = new System.Drawing.Point(86, 63);
            this.edt_Anext.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.edt_Anext.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.edt_Anext.Name = "edt_Anext";
            this.edt_Anext.Size = new System.Drawing.Size(65, 20);
            this.edt_Anext.TabIndex = 50;
            this.edt_Anext.ValueChanged += new System.EventHandler(this.edt_Anext_ValueChanged);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.func_fail);
            this.groupBox12.Controls.Add(this.edt2_func_fail);
            this.groupBox12.Controls.Add(this.edt1_func_fail);
            this.groupBox12.Controls.Add(this.param2_func_fail);
            this.groupBox12.Controls.Add(this.param1_func_fail);
            this.groupBox12.Controls.Add(this.label13);
            this.groupBox12.Location = new System.Drawing.Point(456, 5);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(244, 83);
            this.groupBox12.TabIndex = 43;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "OnFail";
            // 
            // edt2_func_fail
            // 
            this.edt2_func_fail.Location = new System.Drawing.Point(129, 57);
            this.edt2_func_fail.Name = "edt2_func_fail";
            this.edt2_func_fail.Size = new System.Drawing.Size(109, 20);
            this.edt2_func_fail.TabIndex = 50;
            // 
            // edt1_func_fail
            // 
            this.edt1_func_fail.Location = new System.Drawing.Point(129, 35);
            this.edt1_func_fail.Name = "edt1_func_fail";
            this.edt1_func_fail.Size = new System.Drawing.Size(109, 20);
            this.edt1_func_fail.TabIndex = 49;
            // 
            // param2_func_fail
            // 
            this.param2_func_fail.AutoSize = true;
            this.param2_func_fail.Location = new System.Drawing.Point(6, 60);
            this.param2_func_fail.Name = "param2_func_fail";
            this.param2_func_fail.Size = new System.Drawing.Size(46, 13);
            this.param2_func_fail.TabIndex = 46;
            this.param2_func_fail.Text = "Param2:";
            // 
            // param1_func_fail
            // 
            this.param1_func_fail.AutoSize = true;
            this.param1_func_fail.Location = new System.Drawing.Point(6, 38);
            this.param1_func_fail.Name = "param1_func_fail";
            this.param1_func_fail.Size = new System.Drawing.Size(46, 13);
            this.param1_func_fail.TabIndex = 45;
            this.param1_func_fail.Text = "Param1:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 6;
            this.label13.Text = "Funzione:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.func_success);
            this.groupBox1.Controls.Add(this.edt2_func_success);
            this.groupBox1.Controls.Add(this.edt1_func_success);
            this.groupBox1.Controls.Add(this.param2_func_success);
            this.groupBox1.Controls.Add(this.param1_func_success);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(206, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(244, 83);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "OnSuccess";
            // 
            // edt2_func_success
            // 
            this.edt2_func_success.Location = new System.Drawing.Point(129, 57);
            this.edt2_func_success.Name = "edt2_func_success";
            this.edt2_func_success.Size = new System.Drawing.Size(109, 20);
            this.edt2_func_success.TabIndex = 48;
            // 
            // edt1_func_success
            // 
            this.edt1_func_success.Location = new System.Drawing.Point(129, 35);
            this.edt1_func_success.Name = "edt1_func_success";
            this.edt1_func_success.Size = new System.Drawing.Size(109, 20);
            this.edt1_func_success.TabIndex = 47;
            // 
            // param2_func_success
            // 
            this.param2_func_success.AutoSize = true;
            this.param2_func_success.Location = new System.Drawing.Point(6, 60);
            this.param2_func_success.Name = "param2_func_success";
            this.param2_func_success.Size = new System.Drawing.Size(46, 13);
            this.param2_func_success.TabIndex = 46;
            this.param2_func_success.Text = "Param2:";
            // 
            // param1_func_success
            // 
            this.param1_func_success.AutoSize = true;
            this.param1_func_success.Location = new System.Drawing.Point(6, 38);
            this.param1_func_success.Name = "param1_func_success";
            this.param1_func_success.Size = new System.Drawing.Size(46, 13);
            this.param1_func_success.TabIndex = 45;
            this.param1_func_success.Text = "Param1:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Funzione:";
            // 
            // edt_type
            // 
            this.edt_type.Enabled = false;
            this.edt_type.Location = new System.Drawing.Point(86, 33);
            this.edt_type.Name = "edt_type";
            this.edt_type.Size = new System.Drawing.Size(114, 20);
            this.edt_type.TabIndex = 41;
            // 
            // edt_id
            // 
            this.edt_id.Location = new System.Drawing.Point(86, 5);
            this.edt_id.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.edt_id.Name = "edt_id";
            this.edt_id.Size = new System.Drawing.Size(43, 20);
            this.edt_id.TabIndex = 40;
            this.edt_id.ValueChanged += new System.EventHandler(this.edt_id_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 13);
            this.label6.TabIndex = 39;
            this.label6.Text = "ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Successivo: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tipo: ";
            // 
            // combo_Qnext
            // 
            this.combo_Qnext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Qnext.FormattingEnabled = true;
            this.combo_Qnext.Items.AddRange(new object[] {
            "Esci dal dialogo",
            "Attendi Risposta"});
            this.combo_Qnext.Location = new System.Drawing.Point(86, 63);
            this.combo_Qnext.Name = "combo_Qnext";
            this.combo_Qnext.Size = new System.Drawing.Size(114, 21);
            this.combo_Qnext.TabIndex = 50;
            this.combo_Qnext.Visible = false;
            this.combo_Qnext.SelectedIndexChanged += new System.EventHandler(this.combo_Qnext_SelectedIndexChanged);
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tab_text);
            this.tabControl2.Controls.Add(this.tab_unspoken);
            this.tabControl2.Controls.Add(this.tab_before_act);
            this.tabControl2.Controls.Add(this.tab_after_act);
            this.tabControl2.Controls.Add(this.tab_checks);
            this.tabControl2.Location = new System.Drawing.Point(0, 94);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(740, 317);
            this.tabControl2.TabIndex = 27;
            // 
            // tab_text
            // 
            this.tab_text.Controls.Add(this.desc0);
            this.tab_text.Location = new System.Drawing.Point(4, 22);
            this.tab_text.Name = "tab_text";
            this.tab_text.Size = new System.Drawing.Size(732, 291);
            this.tab_text.TabIndex = 5;
            this.tab_text.Text = "Testo";
            this.tab_text.UseVisualStyleBackColor = true;
            // 
            // tab_unspoken
            // 
            this.tab_unspoken.Controls.Add(this.desc1);
            this.tab_unspoken.Location = new System.Drawing.Point(4, 22);
            this.tab_unspoken.Name = "tab_unspoken";
            this.tab_unspoken.Padding = new System.Windows.Forms.Padding(3);
            this.tab_unspoken.Size = new System.Drawing.Size(732, 291);
            this.tab_unspoken.TabIndex = 0;
            this.tab_unspoken.Text = "Unspoken";
            this.tab_unspoken.UseVisualStyleBackColor = true;
            // 
            // tab_before_act
            // 
            this.tab_before_act.Controls.Add(this.desc4);
            this.tab_before_act.Controls.Add(this.panel4);
            this.tab_before_act.Controls.Add(this.panel2);
            this.tab_before_act.Controls.Add(this.panel3);
            this.tab_before_act.Controls.Add(this.desc3);
            this.tab_before_act.Controls.Add(this.desc2);
            this.tab_before_act.Location = new System.Drawing.Point(4, 22);
            this.tab_before_act.Name = "tab_before_act";
            this.tab_before_act.Padding = new System.Windows.Forms.Padding(3);
            this.tab_before_act.Size = new System.Drawing.Size(732, 291);
            this.tab_before_act.TabIndex = 1;
            this.tab_before_act.Text = "Before Act";
            this.tab_before_act.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(0, 173);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(732, 20);
            this.panel4.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "to_room";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.label31);
            this.panel2.Location = new System.Drawing.Point(0, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(732, 20);
            this.panel2.TabIndex = 4;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(3, 4);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(39, 13);
            this.label31.TabIndex = 1;
            this.label31.Text = "to_vict";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel3.Controls.Add(this.label24);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(732, 20);
            this.panel3.TabIndex = 0;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 4);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "to_char";
            // 
            // tab_after_act
            // 
            this.tab_after_act.Controls.Add(this.desc7);
            this.tab_after_act.Controls.Add(this.panel5);
            this.tab_after_act.Controls.Add(this.panel6);
            this.tab_after_act.Controls.Add(this.panel7);
            this.tab_after_act.Controls.Add(this.desc6);
            this.tab_after_act.Controls.Add(this.desc5);
            this.tab_after_act.Location = new System.Drawing.Point(4, 22);
            this.tab_after_act.Name = "tab_after_act";
            this.tab_after_act.Size = new System.Drawing.Size(732, 291);
            this.tab_after_act.TabIndex = 6;
            this.tab_after_act.Text = "After Act";
            this.tab_after_act.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(0, 173);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(732, 20);
            this.panel5.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "to_room";
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel6.Controls.Add(this.label5);
            this.panel6.Location = new System.Drawing.Point(0, 87);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(732, 20);
            this.panel6.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "to_vict";
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(732, 20);
            this.panel7.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "to_char";
            // 
            // tab_checks
            // 
            this.tab_checks.BackColor = System.Drawing.SystemColors.Control;
            this.tab_checks.Controls.Add(this.groupBox3);
            this.tab_checks.Controls.Add(this.groupBox2);
            this.tab_checks.Location = new System.Drawing.Point(4, 22);
            this.tab_checks.Name = "tab_checks";
            this.tab_checks.Size = new System.Drawing.Size(732, 291);
            this.tab_checks.TabIndex = 7;
            this.tab_checks.Text = "Checks e Rolls";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Controls.Add(this.roll9_failbtn);
            this.groupBox3.Controls.Add(this.roll9_fail);
            this.groupBox3.Controls.Add(this.roll9_faillbl);
            this.groupBox3.Controls.Add(this.roll8_failbtn);
            this.groupBox3.Controls.Add(this.roll8_fail);
            this.groupBox3.Controls.Add(this.roll8_faillbl);
            this.groupBox3.Controls.Add(this.roll7_failbtn);
            this.groupBox3.Controls.Add(this.roll7_fail);
            this.groupBox3.Controls.Add(this.roll7_faillbl);
            this.groupBox3.Controls.Add(this.roll6_failbtn);
            this.groupBox3.Controls.Add(this.roll6_fail);
            this.groupBox3.Controls.Add(this.roll6_faillbl);
            this.groupBox3.Controls.Add(this.roll5_failbtn);
            this.groupBox3.Controls.Add(this.roll5_fail);
            this.groupBox3.Controls.Add(this.roll5_faillbl);
            this.groupBox3.Controls.Add(this.roll4_failbtn);
            this.groupBox3.Controls.Add(this.roll4_fail);
            this.groupBox3.Controls.Add(this.roll4_faillbl);
            this.groupBox3.Controls.Add(this.roll3_failbtn);
            this.groupBox3.Controls.Add(this.roll3_fail);
            this.groupBox3.Controls.Add(this.roll3_faillbl);
            this.groupBox3.Controls.Add(this.roll2_failbtn);
            this.groupBox3.Controls.Add(this.roll2_fail);
            this.groupBox3.Controls.Add(this.roll2_faillbl);
            this.groupBox3.Controls.Add(this.roll1_failbtn);
            this.groupBox3.Controls.Add(this.roll1_fail);
            this.groupBox3.Controls.Add(this.roll1_faillbl);
            this.groupBox3.Controls.Add(this.roll0_failbtn);
            this.groupBox3.Controls.Add(this.roll0_fail);
            this.groupBox3.Controls.Add(this.roll0_faillbl);
            this.groupBox3.Controls.Add(this.roll9);
            this.groupBox3.Controls.Add(this.roll9_val);
            this.groupBox3.Controls.Add(this.roll8);
            this.groupBox3.Controls.Add(this.roll8_val);
            this.groupBox3.Controls.Add(this.roll7);
            this.groupBox3.Controls.Add(this.roll7_val);
            this.groupBox3.Controls.Add(this.roll6);
            this.groupBox3.Controls.Add(this.roll6_val);
            this.groupBox3.Controls.Add(this.roll5);
            this.groupBox3.Controls.Add(this.roll5_val);
            this.groupBox3.Controls.Add(this.roll4);
            this.groupBox3.Controls.Add(this.roll4_val);
            this.groupBox3.Controls.Add(this.roll3);
            this.groupBox3.Controls.Add(this.roll3_val);
            this.groupBox3.Controls.Add(this.roll2);
            this.groupBox3.Controls.Add(this.roll2_val);
            this.groupBox3.Controls.Add(this.roll1);
            this.groupBox3.Controls.Add(this.roll1_val);
            this.groupBox3.Controls.Add(this.roll0);
            this.groupBox3.Controls.Add(this.roll0_val);
            this.groupBox3.Location = new System.Drawing.Point(3, 96);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(721, 117);
            this.groupBox3.TabIndex = 69;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Rolls";
            // 
            // roll9_failbtn
            // 
            this.roll9_failbtn.Location = new System.Drawing.Point(690, 89);
            this.roll9_failbtn.Name = "roll9_failbtn";
            this.roll9_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll9_failbtn.TabIndex = 82;
            this.roll9_failbtn.Text = "...";
            this.roll9_failbtn.UseVisualStyleBackColor = true;
            this.roll9_failbtn.Visible = false;
            this.roll9_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll9_fail
            // 
            this.roll9_fail.Location = new System.Drawing.Point(647, 89);
            this.roll9_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll9_fail.Name = "roll9_fail";
            this.roll9_fail.Size = new System.Drawing.Size(37, 20);
            this.roll9_fail.TabIndex = 81;
            this.roll9_fail.Visible = false;
            // 
            // roll9_faillbl
            // 
            this.roll9_faillbl.AutoSize = true;
            this.roll9_faillbl.Location = new System.Drawing.Point(644, 73);
            this.roll9_faillbl.Name = "roll9_faillbl";
            this.roll9_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll9_faillbl.TabIndex = 80;
            this.roll9_faillbl.Text = "Fail:";
            this.roll9_faillbl.Visible = false;
            // 
            // roll8_failbtn
            // 
            this.roll8_failbtn.Location = new System.Drawing.Point(621, 89);
            this.roll8_failbtn.Name = "roll8_failbtn";
            this.roll8_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll8_failbtn.TabIndex = 79;
            this.roll8_failbtn.Text = "...";
            this.roll8_failbtn.UseVisualStyleBackColor = true;
            this.roll8_failbtn.Visible = false;
            this.roll8_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll8_fail
            // 
            this.roll8_fail.Location = new System.Drawing.Point(578, 89);
            this.roll8_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll8_fail.Name = "roll8_fail";
            this.roll8_fail.Size = new System.Drawing.Size(37, 20);
            this.roll8_fail.TabIndex = 78;
            this.roll8_fail.Visible = false;
            // 
            // roll8_faillbl
            // 
            this.roll8_faillbl.AutoSize = true;
            this.roll8_faillbl.Location = new System.Drawing.Point(575, 73);
            this.roll8_faillbl.Name = "roll8_faillbl";
            this.roll8_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll8_faillbl.TabIndex = 77;
            this.roll8_faillbl.Text = "Fail:";
            this.roll8_faillbl.Visible = false;
            // 
            // roll7_failbtn
            // 
            this.roll7_failbtn.Location = new System.Drawing.Point(550, 89);
            this.roll7_failbtn.Name = "roll7_failbtn";
            this.roll7_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll7_failbtn.TabIndex = 76;
            this.roll7_failbtn.Text = "...";
            this.roll7_failbtn.UseVisualStyleBackColor = true;
            this.roll7_failbtn.Visible = false;
            this.roll7_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll7_fail
            // 
            this.roll7_fail.Location = new System.Drawing.Point(507, 89);
            this.roll7_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll7_fail.Name = "roll7_fail";
            this.roll7_fail.Size = new System.Drawing.Size(37, 20);
            this.roll7_fail.TabIndex = 75;
            this.roll7_fail.Visible = false;
            // 
            // roll7_faillbl
            // 
            this.roll7_faillbl.AutoSize = true;
            this.roll7_faillbl.Location = new System.Drawing.Point(504, 73);
            this.roll7_faillbl.Name = "roll7_faillbl";
            this.roll7_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll7_faillbl.TabIndex = 74;
            this.roll7_faillbl.Text = "Fail:";
            this.roll7_faillbl.Visible = false;
            // 
            // roll6_failbtn
            // 
            this.roll6_failbtn.Location = new System.Drawing.Point(477, 89);
            this.roll6_failbtn.Name = "roll6_failbtn";
            this.roll6_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll6_failbtn.TabIndex = 73;
            this.roll6_failbtn.Text = "...";
            this.roll6_failbtn.UseVisualStyleBackColor = true;
            this.roll6_failbtn.Visible = false;
            this.roll6_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll6_fail
            // 
            this.roll6_fail.Location = new System.Drawing.Point(434, 89);
            this.roll6_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll6_fail.Name = "roll6_fail";
            this.roll6_fail.Size = new System.Drawing.Size(37, 20);
            this.roll6_fail.TabIndex = 72;
            this.roll6_fail.Visible = false;
            // 
            // roll6_faillbl
            // 
            this.roll6_faillbl.AutoSize = true;
            this.roll6_faillbl.Location = new System.Drawing.Point(431, 73);
            this.roll6_faillbl.Name = "roll6_faillbl";
            this.roll6_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll6_faillbl.TabIndex = 71;
            this.roll6_faillbl.Text = "Fail:";
            this.roll6_faillbl.Visible = false;
            // 
            // roll5_failbtn
            // 
            this.roll5_failbtn.Location = new System.Drawing.Point(408, 89);
            this.roll5_failbtn.Name = "roll5_failbtn";
            this.roll5_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll5_failbtn.TabIndex = 70;
            this.roll5_failbtn.Text = "...";
            this.roll5_failbtn.UseVisualStyleBackColor = true;
            this.roll5_failbtn.Visible = false;
            this.roll5_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll5_fail
            // 
            this.roll5_fail.Location = new System.Drawing.Point(365, 89);
            this.roll5_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll5_fail.Name = "roll5_fail";
            this.roll5_fail.Size = new System.Drawing.Size(37, 20);
            this.roll5_fail.TabIndex = 69;
            this.roll5_fail.Visible = false;
            // 
            // roll5_faillbl
            // 
            this.roll5_faillbl.AutoSize = true;
            this.roll5_faillbl.Location = new System.Drawing.Point(362, 73);
            this.roll5_faillbl.Name = "roll5_faillbl";
            this.roll5_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll5_faillbl.TabIndex = 68;
            this.roll5_faillbl.Text = "Fail:";
            this.roll5_faillbl.Visible = false;
            // 
            // roll4_failbtn
            // 
            this.roll4_failbtn.Location = new System.Drawing.Point(337, 89);
            this.roll4_failbtn.Name = "roll4_failbtn";
            this.roll4_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll4_failbtn.TabIndex = 67;
            this.roll4_failbtn.Text = "...";
            this.roll4_failbtn.UseVisualStyleBackColor = true;
            this.roll4_failbtn.Visible = false;
            this.roll4_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll4_fail
            // 
            this.roll4_fail.Location = new System.Drawing.Point(294, 89);
            this.roll4_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll4_fail.Name = "roll4_fail";
            this.roll4_fail.Size = new System.Drawing.Size(37, 20);
            this.roll4_fail.TabIndex = 66;
            this.roll4_fail.Visible = false;
            // 
            // roll4_faillbl
            // 
            this.roll4_faillbl.AutoSize = true;
            this.roll4_faillbl.Location = new System.Drawing.Point(291, 73);
            this.roll4_faillbl.Name = "roll4_faillbl";
            this.roll4_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll4_faillbl.TabIndex = 65;
            this.roll4_faillbl.Text = "Fail:";
            this.roll4_faillbl.Visible = false;
            // 
            // roll3_failbtn
            // 
            this.roll3_failbtn.Location = new System.Drawing.Point(264, 89);
            this.roll3_failbtn.Name = "roll3_failbtn";
            this.roll3_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll3_failbtn.TabIndex = 64;
            this.roll3_failbtn.Text = "...";
            this.roll3_failbtn.UseVisualStyleBackColor = true;
            this.roll3_failbtn.Visible = false;
            this.roll3_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll3_fail
            // 
            this.roll3_fail.Location = new System.Drawing.Point(221, 89);
            this.roll3_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll3_fail.Name = "roll3_fail";
            this.roll3_fail.Size = new System.Drawing.Size(37, 20);
            this.roll3_fail.TabIndex = 63;
            this.roll3_fail.Visible = false;
            // 
            // roll3_faillbl
            // 
            this.roll3_faillbl.AutoSize = true;
            this.roll3_faillbl.Location = new System.Drawing.Point(218, 73);
            this.roll3_faillbl.Name = "roll3_faillbl";
            this.roll3_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll3_faillbl.TabIndex = 62;
            this.roll3_faillbl.Text = "Fail:";
            this.roll3_faillbl.Visible = false;
            // 
            // roll2_failbtn
            // 
            this.roll2_failbtn.Location = new System.Drawing.Point(193, 89);
            this.roll2_failbtn.Name = "roll2_failbtn";
            this.roll2_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll2_failbtn.TabIndex = 61;
            this.roll2_failbtn.Text = "...";
            this.roll2_failbtn.UseVisualStyleBackColor = true;
            this.roll2_failbtn.Visible = false;
            this.roll2_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll2_fail
            // 
            this.roll2_fail.Location = new System.Drawing.Point(150, 89);
            this.roll2_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll2_fail.Name = "roll2_fail";
            this.roll2_fail.Size = new System.Drawing.Size(37, 20);
            this.roll2_fail.TabIndex = 60;
            this.roll2_fail.Visible = false;
            // 
            // roll2_faillbl
            // 
            this.roll2_faillbl.AutoSize = true;
            this.roll2_faillbl.Location = new System.Drawing.Point(147, 73);
            this.roll2_faillbl.Name = "roll2_faillbl";
            this.roll2_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll2_faillbl.TabIndex = 59;
            this.roll2_faillbl.Text = "Fail:";
            this.roll2_faillbl.Visible = false;
            // 
            // roll1_failbtn
            // 
            this.roll1_failbtn.Location = new System.Drawing.Point(122, 89);
            this.roll1_failbtn.Name = "roll1_failbtn";
            this.roll1_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll1_failbtn.TabIndex = 58;
            this.roll1_failbtn.Text = "...";
            this.roll1_failbtn.UseVisualStyleBackColor = true;
            this.roll1_failbtn.Visible = false;
            this.roll1_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll1_fail
            // 
            this.roll1_fail.Location = new System.Drawing.Point(79, 89);
            this.roll1_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll1_fail.Name = "roll1_fail";
            this.roll1_fail.Size = new System.Drawing.Size(37, 20);
            this.roll1_fail.TabIndex = 57;
            this.roll1_fail.Visible = false;
            // 
            // roll1_faillbl
            // 
            this.roll1_faillbl.AutoSize = true;
            this.roll1_faillbl.Location = new System.Drawing.Point(76, 73);
            this.roll1_faillbl.Name = "roll1_faillbl";
            this.roll1_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll1_faillbl.TabIndex = 56;
            this.roll1_faillbl.Text = "Fail:";
            this.roll1_faillbl.Visible = false;
            // 
            // roll0_failbtn
            // 
            this.roll0_failbtn.Location = new System.Drawing.Point(49, 89);
            this.roll0_failbtn.Name = "roll0_failbtn";
            this.roll0_failbtn.Size = new System.Drawing.Size(21, 20);
            this.roll0_failbtn.TabIndex = 55;
            this.roll0_failbtn.Text = "...";
            this.roll0_failbtn.UseVisualStyleBackColor = true;
            this.roll0_failbtn.Visible = false;
            this.roll0_failbtn.Click += new System.EventHandler(this.roll0_failbtn_Click);
            // 
            // roll0_fail
            // 
            this.roll0_fail.Location = new System.Drawing.Point(6, 89);
            this.roll0_fail.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll0_fail.Name = "roll0_fail";
            this.roll0_fail.Size = new System.Drawing.Size(37, 20);
            this.roll0_fail.TabIndex = 54;
            this.roll0_fail.Visible = false;
            // 
            // roll0_faillbl
            // 
            this.roll0_faillbl.AutoSize = true;
            this.roll0_faillbl.Location = new System.Drawing.Point(3, 73);
            this.roll0_faillbl.Name = "roll0_faillbl";
            this.roll0_faillbl.Size = new System.Drawing.Size(26, 13);
            this.roll0_faillbl.TabIndex = 53;
            this.roll0_faillbl.Text = "Fail:";
            this.roll0_faillbl.Visible = false;
            // 
            // roll9
            // 
            this.roll9.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll9.Location = new System.Drawing.Point(647, 19);
            this.roll9.Name = "roll9";
            this.roll9.Size = new System.Drawing.Size(65, 25);
            this.roll9.TabIndex = 51;
            this.roll9.Text = "Mob State";
            this.roll9.UseVisualStyleBackColor = false;
            this.roll9.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll9_val
            // 
            this.roll9_val.Location = new System.Drawing.Point(647, 50);
            this.roll9_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll9_val.Name = "roll9_val";
            this.roll9_val.Size = new System.Drawing.Size(65, 20);
            this.roll9_val.TabIndex = 52;
            this.roll9_val.Visible = false;
            // 
            // roll8
            // 
            this.roll8.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll8.Location = new System.Drawing.Point(576, 19);
            this.roll8.Name = "roll8";
            this.roll8.Size = new System.Drawing.Size(65, 25);
            this.roll8.TabIndex = 49;
            this.roll8.Text = "Room Loc";
            this.roll8.UseVisualStyleBackColor = false;
            this.roll8.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll8_val
            // 
            this.roll8_val.Location = new System.Drawing.Point(576, 50);
            this.roll8_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll8_val.Name = "roll8_val";
            this.roll8_val.Size = new System.Drawing.Size(65, 20);
            this.roll8_val.TabIndex = 50;
            this.roll8_val.Visible = false;
            // 
            // roll7
            // 
            this.roll7.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll7.Location = new System.Drawing.Point(505, 19);
            this.roll7.Name = "roll7";
            this.roll7.Size = new System.Drawing.Size(65, 25);
            this.roll7.TabIndex = 47;
            this.roll7.Text = "Equip Obj";
            this.roll7.UseVisualStyleBackColor = false;
            this.roll7.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll7_val
            // 
            this.roll7_val.Location = new System.Drawing.Point(505, 50);
            this.roll7_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll7_val.Name = "roll7_val";
            this.roll7_val.Size = new System.Drawing.Size(65, 20);
            this.roll7_val.TabIndex = 48;
            this.roll7_val.Visible = false;
            // 
            // roll6
            // 
            this.roll6.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll6.Location = new System.Drawing.Point(434, 19);
            this.roll6.Name = "roll6";
            this.roll6.Size = new System.Drawing.Size(65, 25);
            this.roll6.TabIndex = 45;
            this.roll6.Text = "Inv Obj";
            this.roll6.UseVisualStyleBackColor = false;
            this.roll6.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll6_val
            // 
            this.roll6_val.Location = new System.Drawing.Point(434, 50);
            this.roll6_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll6_val.Name = "roll6_val";
            this.roll6_val.Size = new System.Drawing.Size(65, 20);
            this.roll6_val.TabIndex = 46;
            this.roll6_val.Visible = false;
            // 
            // roll5
            // 
            this.roll5.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll5.Location = new System.Drawing.Point(363, 19);
            this.roll5.Name = "roll5";
            this.roll5.Size = new System.Drawing.Size(65, 25);
            this.roll5.TabIndex = 43;
            this.roll5.Text = "Charisma";
            this.roll5.UseVisualStyleBackColor = false;
            this.roll5.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll5_val
            // 
            this.roll5_val.Location = new System.Drawing.Point(363, 50);
            this.roll5_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll5_val.Name = "roll5_val";
            this.roll5_val.Size = new System.Drawing.Size(65, 20);
            this.roll5_val.TabIndex = 44;
            this.roll5_val.Visible = false;
            // 
            // roll4
            // 
            this.roll4.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll4.Location = new System.Drawing.Point(292, 19);
            this.roll4.Name = "roll4";
            this.roll4.Size = new System.Drawing.Size(65, 25);
            this.roll4.TabIndex = 41;
            this.roll4.Text = "Const.";
            this.roll4.UseVisualStyleBackColor = false;
            this.roll4.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll4_val
            // 
            this.roll4_val.Location = new System.Drawing.Point(292, 50);
            this.roll4_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll4_val.Name = "roll4_val";
            this.roll4_val.Size = new System.Drawing.Size(65, 20);
            this.roll4_val.TabIndex = 42;
            this.roll4_val.Visible = false;
            // 
            // roll3
            // 
            this.roll3.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll3.Location = new System.Drawing.Point(221, 19);
            this.roll3.Name = "roll3";
            this.roll3.Size = new System.Drawing.Size(65, 25);
            this.roll3.TabIndex = 39;
            this.roll3.Text = "Wisdom";
            this.roll3.UseVisualStyleBackColor = false;
            this.roll3.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll3_val
            // 
            this.roll3_val.Location = new System.Drawing.Point(221, 50);
            this.roll3_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll3_val.Name = "roll3_val";
            this.roll3_val.Size = new System.Drawing.Size(65, 20);
            this.roll3_val.TabIndex = 40;
            this.roll3_val.Visible = false;
            // 
            // roll2
            // 
            this.roll2.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll2.Location = new System.Drawing.Point(150, 19);
            this.roll2.Name = "roll2";
            this.roll2.Size = new System.Drawing.Size(65, 25);
            this.roll2.TabIndex = 37;
            this.roll2.Text = "Intellect";
            this.roll2.UseVisualStyleBackColor = false;
            this.roll2.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll2_val
            // 
            this.roll2_val.Location = new System.Drawing.Point(150, 50);
            this.roll2_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll2_val.Name = "roll2_val";
            this.roll2_val.Size = new System.Drawing.Size(65, 20);
            this.roll2_val.TabIndex = 38;
            this.roll2_val.Visible = false;
            // 
            // roll1
            // 
            this.roll1.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll1.Location = new System.Drawing.Point(77, 19);
            this.roll1.Name = "roll1";
            this.roll1.Size = new System.Drawing.Size(65, 25);
            this.roll1.TabIndex = 35;
            this.roll1.Text = "Dexterity";
            this.roll1.UseVisualStyleBackColor = false;
            this.roll1.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll1_val
            // 
            this.roll1_val.Location = new System.Drawing.Point(79, 50);
            this.roll1_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll1_val.Name = "roll1_val";
            this.roll1_val.Size = new System.Drawing.Size(65, 20);
            this.roll1_val.TabIndex = 36;
            this.roll1_val.Visible = false;
            // 
            // roll0
            // 
            this.roll0.Appearance = System.Windows.Forms.Appearance.Button;
            this.roll0.Location = new System.Drawing.Point(6, 19);
            this.roll0.Name = "roll0";
            this.roll0.Size = new System.Drawing.Size(65, 25);
            this.roll0.TabIndex = 25;
            this.roll0.Text = "Strength";
            this.roll0.UseVisualStyleBackColor = false;
            this.roll0.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // roll0_val
            // 
            this.roll0_val.Location = new System.Drawing.Point(6, 50);
            this.roll0_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.roll0_val.Name = "roll0_val";
            this.roll0_val.Size = new System.Drawing.Size(65, 20);
            this.roll0_val.TabIndex = 34;
            this.roll0_val.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.check9);
            this.groupBox2.Controls.Add(this.check9_val);
            this.groupBox2.Controls.Add(this.check8);
            this.groupBox2.Controls.Add(this.check8_val);
            this.groupBox2.Controls.Add(this.check7);
            this.groupBox2.Controls.Add(this.check7_val);
            this.groupBox2.Controls.Add(this.check6);
            this.groupBox2.Controls.Add(this.check6_val);
            this.groupBox2.Controls.Add(this.check5);
            this.groupBox2.Controls.Add(this.check5_val);
            this.groupBox2.Controls.Add(this.check4);
            this.groupBox2.Controls.Add(this.check4_val);
            this.groupBox2.Controls.Add(this.check3);
            this.groupBox2.Controls.Add(this.check3_val);
            this.groupBox2.Controls.Add(this.check2);
            this.groupBox2.Controls.Add(this.check2_val);
            this.groupBox2.Controls.Add(this.check1);
            this.groupBox2.Controls.Add(this.check1_val);
            this.groupBox2.Controls.Add(this.check0);
            this.groupBox2.Controls.Add(this.check0_val);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(721, 87);
            this.groupBox2.TabIndex = 68;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Checks";
            // 
            // check9
            // 
            this.check9.Appearance = System.Windows.Forms.Appearance.Button;
            this.check9.Location = new System.Drawing.Point(647, 19);
            this.check9.Name = "check9";
            this.check9.Size = new System.Drawing.Size(65, 25);
            this.check9.TabIndex = 51;
            this.check9.Text = "Mob State";
            this.check9.UseVisualStyleBackColor = false;
            this.check9.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check9_val
            // 
            this.check9_val.Location = new System.Drawing.Point(647, 50);
            this.check9_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check9_val.Name = "check9_val";
            this.check9_val.Size = new System.Drawing.Size(65, 20);
            this.check9_val.TabIndex = 52;
            this.check9_val.Visible = false;
            // 
            // check8
            // 
            this.check8.Appearance = System.Windows.Forms.Appearance.Button;
            this.check8.Location = new System.Drawing.Point(576, 19);
            this.check8.Name = "check8";
            this.check8.Size = new System.Drawing.Size(65, 25);
            this.check8.TabIndex = 49;
            this.check8.Text = "Room Loc";
            this.check8.UseVisualStyleBackColor = false;
            this.check8.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check8_val
            // 
            this.check8_val.Location = new System.Drawing.Point(576, 50);
            this.check8_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check8_val.Name = "check8_val";
            this.check8_val.Size = new System.Drawing.Size(65, 20);
            this.check8_val.TabIndex = 50;
            this.check8_val.Visible = false;
            // 
            // check7
            // 
            this.check7.Appearance = System.Windows.Forms.Appearance.Button;
            this.check7.Location = new System.Drawing.Point(505, 19);
            this.check7.Name = "check7";
            this.check7.Size = new System.Drawing.Size(65, 25);
            this.check7.TabIndex = 47;
            this.check7.Text = "Equip Obj";
            this.check7.UseVisualStyleBackColor = false;
            this.check7.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check7_val
            // 
            this.check7_val.Location = new System.Drawing.Point(505, 50);
            this.check7_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check7_val.Name = "check7_val";
            this.check7_val.Size = new System.Drawing.Size(65, 20);
            this.check7_val.TabIndex = 48;
            this.check7_val.Visible = false;
            // 
            // check6
            // 
            this.check6.Appearance = System.Windows.Forms.Appearance.Button;
            this.check6.Location = new System.Drawing.Point(434, 19);
            this.check6.Name = "check6";
            this.check6.Size = new System.Drawing.Size(65, 25);
            this.check6.TabIndex = 45;
            this.check6.Text = "Inv Obj";
            this.check6.UseVisualStyleBackColor = false;
            this.check6.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check6_val
            // 
            this.check6_val.Location = new System.Drawing.Point(434, 50);
            this.check6_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check6_val.Name = "check6_val";
            this.check6_val.Size = new System.Drawing.Size(65, 20);
            this.check6_val.TabIndex = 46;
            this.check6_val.Visible = false;
            // 
            // check5
            // 
            this.check5.Appearance = System.Windows.Forms.Appearance.Button;
            this.check5.Location = new System.Drawing.Point(363, 19);
            this.check5.Name = "check5";
            this.check5.Size = new System.Drawing.Size(65, 25);
            this.check5.TabIndex = 43;
            this.check5.Text = "Charisma";
            this.check5.UseVisualStyleBackColor = false;
            this.check5.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check5_val
            // 
            this.check5_val.Location = new System.Drawing.Point(363, 50);
            this.check5_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check5_val.Name = "check5_val";
            this.check5_val.Size = new System.Drawing.Size(65, 20);
            this.check5_val.TabIndex = 44;
            this.check5_val.Visible = false;
            // 
            // check4
            // 
            this.check4.Appearance = System.Windows.Forms.Appearance.Button;
            this.check4.Location = new System.Drawing.Point(292, 19);
            this.check4.Name = "check4";
            this.check4.Size = new System.Drawing.Size(65, 25);
            this.check4.TabIndex = 41;
            this.check4.Text = "Const.";
            this.check4.UseVisualStyleBackColor = false;
            this.check4.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check4_val
            // 
            this.check4_val.Location = new System.Drawing.Point(292, 50);
            this.check4_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check4_val.Name = "check4_val";
            this.check4_val.Size = new System.Drawing.Size(65, 20);
            this.check4_val.TabIndex = 42;
            this.check4_val.Visible = false;
            // 
            // check3
            // 
            this.check3.Appearance = System.Windows.Forms.Appearance.Button;
            this.check3.Location = new System.Drawing.Point(221, 19);
            this.check3.Name = "check3";
            this.check3.Size = new System.Drawing.Size(65, 25);
            this.check3.TabIndex = 39;
            this.check3.Text = "Wisdom";
            this.check3.UseVisualStyleBackColor = false;
            this.check3.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check3_val
            // 
            this.check3_val.Location = new System.Drawing.Point(221, 50);
            this.check3_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check3_val.Name = "check3_val";
            this.check3_val.Size = new System.Drawing.Size(65, 20);
            this.check3_val.TabIndex = 40;
            this.check3_val.Visible = false;
            // 
            // check2
            // 
            this.check2.Appearance = System.Windows.Forms.Appearance.Button;
            this.check2.Location = new System.Drawing.Point(150, 19);
            this.check2.Name = "check2";
            this.check2.Size = new System.Drawing.Size(65, 25);
            this.check2.TabIndex = 37;
            this.check2.Text = "Intellect";
            this.check2.UseVisualStyleBackColor = false;
            this.check2.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check2_val
            // 
            this.check2_val.Location = new System.Drawing.Point(150, 50);
            this.check2_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check2_val.Name = "check2_val";
            this.check2_val.Size = new System.Drawing.Size(65, 20);
            this.check2_val.TabIndex = 38;
            this.check2_val.Visible = false;
            // 
            // check1
            // 
            this.check1.Appearance = System.Windows.Forms.Appearance.Button;
            this.check1.Location = new System.Drawing.Point(77, 19);
            this.check1.Name = "check1";
            this.check1.Size = new System.Drawing.Size(65, 25);
            this.check1.TabIndex = 35;
            this.check1.Text = "Dexterity";
            this.check1.UseVisualStyleBackColor = false;
            this.check1.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check1_val
            // 
            this.check1_val.Location = new System.Drawing.Point(79, 50);
            this.check1_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check1_val.Name = "check1_val";
            this.check1_val.Size = new System.Drawing.Size(65, 20);
            this.check1_val.TabIndex = 36;
            this.check1_val.Visible = false;
            // 
            // check0
            // 
            this.check0.Appearance = System.Windows.Forms.Appearance.Button;
            this.check0.Location = new System.Drawing.Point(6, 19);
            this.check0.Name = "check0";
            this.check0.Size = new System.Drawing.Size(65, 25);
            this.check0.TabIndex = 25;
            this.check0.Text = "Strength";
            this.check0.UseVisualStyleBackColor = false;
            this.check0.CheckedChanged += new System.EventHandler(this.check9_CheckedChanged);
            // 
            // check0_val
            // 
            this.check0_val.Location = new System.Drawing.Point(6, 50);
            this.check0_val.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.check0_val.Name = "check0_val";
            this.check0_val.Size = new System.Drawing.Size(65, 20);
            this.check0_val.TabIndex = 34;
            this.check0_val.Visible = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btncancel);
            this.panel8.Controls.Add(this.btnok);
            this.panel8.Controls.Add(this.btnapply);
            this.panel8.Controls.Add(this.btnrestore);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 461);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(740, 31);
            this.panel8.TabIndex = 28;
            // 
            // gaugecharcounter
            // 
            this.gaugecharcounter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gaugecharcounter.Location = new System.Drawing.Point(4, 411);
            this.gaugecharcounter.Name = "gaugecharcounter";
            this.gaugecharcounter.Size = new System.Drawing.Size(732, 18);
            this.gaugecharcounter.TabIndex = 76;
            // 
            // desc0
            // 
            this.desc0.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc0.DetectUrls = false;
            this.desc0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.desc0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc0.Location = new System.Drawing.Point(0, 0);
            this.desc0.Name = "desc0";
            this.desc0.Size = new System.Drawing.Size(732, 291);
            this.desc0.TabIndex = 3;
            this.desc0.Text = "";
            this.desc0.WordWrap = false;
            // 
            // desc1
            // 
            this.desc1.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc1.DetectUrls = false;
            this.desc1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.desc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc1.Location = new System.Drawing.Point(3, 3);
            this.desc1.Name = "desc1";
            this.desc1.Size = new System.Drawing.Size(726, 285);
            this.desc1.TabIndex = 1;
            this.desc1.Text = "";
            this.desc1.WordWrap = false;
            // 
            // desc4
            // 
            this.desc4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.desc4.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc4.DetectUrls = false;
            this.desc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc4.Location = new System.Drawing.Point(0, 193);
            this.desc4.Name = "desc4";
            this.desc4.Size = new System.Drawing.Size(726, 95);
            this.desc4.TabIndex = 6;
            this.desc4.Text = "";
            this.desc4.WordWrap = false;
            // 
            // desc3
            // 
            this.desc3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.desc3.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc3.DetectUrls = false;
            this.desc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc3.Location = new System.Drawing.Point(0, 106);
            this.desc3.Name = "desc3";
            this.desc3.Size = new System.Drawing.Size(726, 67);
            this.desc3.TabIndex = 2;
            this.desc3.Text = "";
            this.desc3.WordWrap = false;
            // 
            // desc2
            // 
            this.desc2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.desc2.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc2.DetectUrls = false;
            this.desc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc2.Location = new System.Drawing.Point(0, 19);
            this.desc2.Name = "desc2";
            this.desc2.Size = new System.Drawing.Size(726, 67);
            this.desc2.TabIndex = 1;
            this.desc2.Text = "";
            this.desc2.WordWrap = false;
            // 
            // desc7
            // 
            this.desc7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.desc7.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc7.DetectUrls = false;
            this.desc7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc7.Location = new System.Drawing.Point(0, 193);
            this.desc7.Name = "desc7";
            this.desc7.Size = new System.Drawing.Size(726, 95);
            this.desc7.TabIndex = 12;
            this.desc7.Text = "";
            this.desc7.WordWrap = false;
            // 
            // desc6
            // 
            this.desc6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.desc6.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc6.DetectUrls = false;
            this.desc6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc6.Location = new System.Drawing.Point(0, 19);
            this.desc6.Name = "desc6";
            this.desc6.Size = new System.Drawing.Size(726, 67);
            this.desc6.TabIndex = 8;
            this.desc6.Text = "";
            this.desc6.WordWrap = false;
            // 
            // desc5
            // 
            this.desc5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.desc5.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.desc5.DetectUrls = false;
            this.desc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.desc5.Location = new System.Drawing.Point(0, 106);
            this.desc5.Name = "desc5";
            this.desc5.Size = new System.Drawing.Size(726, 67);
            this.desc5.TabIndex = 7;
            this.desc5.Text = "";
            this.desc5.WordWrap = false;
            // 
            // func_fail
            // 
            this.func_fail.Location = new System.Drawing.Point(129, 14);
            this.func_fail.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.func_fail.Minimum = new decimal(new int[] {
            -2147483648,
            0,
            0,
            -2147483648});
            this.func_fail.Name = "func_fail";
            this.func_fail.Size = new System.Drawing.Size(109, 20);
            this.func_fail.TabIndex = 51;
            this.func_fail.ValueType = '\0';
            this.func_fail.ValueChanged += new System.EventHandler(this.func_success_ValueChanged);
            // 
            // func_success
            // 
            this.func_success.Location = new System.Drawing.Point(129, 14);
            this.func_success.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.func_success.Minimum = new decimal(new int[] {
            -2147483648,
            0,
            0,
            -2147483648});
            this.func_success.Name = "func_success";
            this.func_success.Size = new System.Drawing.Size(109, 20);
            this.func_success.TabIndex = 49;
            this.func_success.ValueType = '\0';
            this.func_success.ValueChanged += new System.EventHandler(this.func_success_ValueChanged);
            // 
            // frm_MobDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 492);
            this.Controls.Add(this.gaugecharcounter);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(756, 531);
            this.Name = "frm_MobDialogue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dialogo";
            this.Shown += new System.EventHandler(this.frm_MobDialog_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_Anext)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_id)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tab_text.ResumeLayout(false);
            this.tab_unspoken.ResumeLayout(false);
            this.tab_before_act.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tab_after_act.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tab_checks.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roll9_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll8_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll7_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll6_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll5_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll4_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll3_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll2_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll1_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll0_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll9_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll8_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll7_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll6_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll5_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll4_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll3_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll2_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll1_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roll0_val)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.check9_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check8_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check7_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check6_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check5_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check4_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check3_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check2_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check1_val)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.check0_val)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.func_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.func_success)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnapply;
        private System.Windows.Forms.Button btnrestore;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tab_text;
        private MudlikeRichTextBox desc0;
        private System.Windows.Forms.TabPage tab_unspoken;
        private MudlikeRichTextBox desc1;
        private System.Windows.Forms.TabPage tab_before_act;
        private MudlikeRichTextBox desc4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private MudlikeRichTextBox desc3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label31;
        private MudlikeRichTextBox desc2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TabPage tab_after_act;
        private MudlikeRichTextBox desc7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private MudlikeRichTextBox desc6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private MudlikeRichTextBox desc5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown edt_id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tab_checks;
        private CharCounterProgressBar gaugecharcounter;
        private System.Windows.Forms.TextBox edt_type;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label param2_func_fail;
        private System.Windows.Forms.Label param1_func_fail;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label param2_func_success;
        private System.Windows.Forms.Label param1_func_success;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox edt1_func_success;
        private System.Windows.Forms.TextBox edt2_func_fail;
        private System.Windows.Forms.TextBox edt1_func_fail;
        private System.Windows.Forms.TextBox edt2_func_success;
        private ValAffEditbox func_fail;
        private ValAffEditbox func_success;
        private System.Windows.Forms.Button btn_Afindnext;
        private System.Windows.Forms.NumericUpDown edt_Anext;
        private System.Windows.Forms.ComboBox combo_Qnext;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label roll9_faillbl;
        private System.Windows.Forms.Label roll8_faillbl;
        private System.Windows.Forms.Label roll7_faillbl;
        private System.Windows.Forms.Label roll6_faillbl;
        private System.Windows.Forms.Label roll5_faillbl;
        private System.Windows.Forms.Label roll4_faillbl;
        private System.Windows.Forms.Label roll3_faillbl;
        private System.Windows.Forms.Label roll2_faillbl;
        private System.Windows.Forms.Label roll1_faillbl;
        private System.Windows.Forms.Label roll0_faillbl;
        private System.Windows.Forms.CheckBox roll9;
        private System.Windows.Forms.NumericUpDown roll9_val;
        private System.Windows.Forms.CheckBox roll8;
        private System.Windows.Forms.NumericUpDown roll8_val;
        private System.Windows.Forms.CheckBox roll7;
        private System.Windows.Forms.NumericUpDown roll7_val;
        private System.Windows.Forms.CheckBox roll6;
        private System.Windows.Forms.NumericUpDown roll6_val;
        private System.Windows.Forms.CheckBox roll5;
        private System.Windows.Forms.NumericUpDown roll5_val;
        private System.Windows.Forms.CheckBox roll4;
        private System.Windows.Forms.NumericUpDown roll4_val;
        private System.Windows.Forms.CheckBox roll3;
        private System.Windows.Forms.NumericUpDown roll3_val;
        private System.Windows.Forms.CheckBox roll2;
        private System.Windows.Forms.NumericUpDown roll2_val;
        private System.Windows.Forms.CheckBox roll1;
        private System.Windows.Forms.NumericUpDown roll1_val;
        private System.Windows.Forms.CheckBox roll0;
        private System.Windows.Forms.NumericUpDown roll0_val;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox check9;
        private System.Windows.Forms.NumericUpDown check9_val;
        private System.Windows.Forms.CheckBox check8;
        private System.Windows.Forms.NumericUpDown check8_val;
        private System.Windows.Forms.CheckBox check7;
        private System.Windows.Forms.NumericUpDown check7_val;
        private System.Windows.Forms.CheckBox check6;
        private System.Windows.Forms.NumericUpDown check6_val;
        private System.Windows.Forms.CheckBox check5;
        private System.Windows.Forms.NumericUpDown check5_val;
        private System.Windows.Forms.CheckBox check4;
        private System.Windows.Forms.NumericUpDown check4_val;
        private System.Windows.Forms.CheckBox check3;
        private System.Windows.Forms.NumericUpDown check3_val;
        private System.Windows.Forms.CheckBox check2;
        private System.Windows.Forms.NumericUpDown check2_val;
        private System.Windows.Forms.CheckBox check1;
        private System.Windows.Forms.NumericUpDown check1_val;
        private System.Windows.Forms.CheckBox check0;
        private System.Windows.Forms.NumericUpDown check0_val;
        private System.Windows.Forms.Button roll9_failbtn;
        private System.Windows.Forms.NumericUpDown roll9_fail;
        private System.Windows.Forms.Button roll8_failbtn;
        private System.Windows.Forms.NumericUpDown roll8_fail;
        private System.Windows.Forms.Button roll7_failbtn;
        private System.Windows.Forms.NumericUpDown roll7_fail;
        private System.Windows.Forms.Button roll6_failbtn;
        private System.Windows.Forms.NumericUpDown roll6_fail;
        private System.Windows.Forms.Button roll5_failbtn;
        private System.Windows.Forms.NumericUpDown roll5_fail;
        private System.Windows.Forms.Button roll4_failbtn;
        private System.Windows.Forms.NumericUpDown roll4_fail;
        private System.Windows.Forms.Button roll3_failbtn;
        private System.Windows.Forms.NumericUpDown roll3_fail;
        private System.Windows.Forms.Button roll2_failbtn;
        private System.Windows.Forms.NumericUpDown roll2_fail;
        private System.Windows.Forms.Button roll1_failbtn;
        private System.Windows.Forms.NumericUpDown roll1_fail;
        private System.Windows.Forms.Button roll0_failbtn;
        private System.Windows.Forms.NumericUpDown roll0_fail;
    }
}