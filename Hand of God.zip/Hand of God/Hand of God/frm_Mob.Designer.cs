﻿namespace HandofGod
{
    partial class frm_Mob
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.edt_shortdesc = new HandofGod.MudlikeRichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.edt_keys = new System.Windows.Forms.TextBox();
            this.memo_longdesc = new HandofGod.MudlikeRichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.val0 = new System.Windows.Forms.ComboBox();
            this.val4 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.val9 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.val11 = new System.Windows.Forms.ComboBox();
            this.val12 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.val2 = new System.Windows.Forms.NumericUpDown();
            this.val7 = new System.Windows.Forms.NumericUpDown();
            this.val13 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.val1 = new System.Windows.Forms.NumericUpDown();
            this.val3 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.val10 = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.val6 = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.val8 = new System.Windows.Forms.NumericUpDown();
            this.val5 = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.lblavghp = new System.Windows.Forms.Label();
            this.lblavgxp = new System.Windows.Forms.Label();
            this.edt_damage = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_acts = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.act20 = new System.Windows.Forms.CheckBox();
            this.act13 = new System.Windows.Forms.CheckBox();
            this.act12 = new System.Windows.Forms.CheckBox();
            this.act10 = new System.Windows.Forms.CheckBox();
            this.act8 = new System.Windows.Forms.CheckBox();
            this.act9 = new System.Windows.Forms.CheckBox();
            this.act7 = new System.Windows.Forms.CheckBox();
            this.act4 = new System.Windows.Forms.CheckBox();
            this.act2 = new System.Windows.Forms.CheckBox();
            this.act15 = new System.Windows.Forms.CheckBox();
            this.act5 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.act19 = new System.Windows.Forms.CheckBox();
            this.act11 = new System.Windows.Forms.CheckBox();
            this.act3 = new System.Windows.Forms.CheckBox();
            this.act18 = new System.Windows.Forms.CheckBox();
            this.act17 = new System.Windows.Forms.CheckBox();
            this.act16 = new System.Windows.Forms.CheckBox();
            this.act14 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.act6 = new System.Windows.Forms.CheckBox();
            this.act1 = new System.Windows.Forms.CheckBox();
            this.act0 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.act31 = new System.Windows.Forms.CheckBox();
            this.act30 = new System.Windows.Forms.CheckBox();
            this.act29 = new System.Windows.Forms.CheckBox();
            this.act28 = new System.Windows.Forms.CheckBox();
            this.act27 = new System.Windows.Forms.CheckBox();
            this.act26 = new System.Windows.Forms.CheckBox();
            this.act25 = new System.Windows.Forms.CheckBox();
            this.act24 = new System.Windows.Forms.CheckBox();
            this.act23 = new System.Windows.Forms.CheckBox();
            this.act22 = new System.Windows.Forms.CheckBox();
            this.act21 = new System.Windows.Forms.CheckBox();
            this.tab_affects = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.aff8 = new System.Windows.Forms.CheckBox();
            this.aff4 = new System.Windows.Forms.CheckBox();
            this.aff2 = new System.Windows.Forms.CheckBox();
            this.aff5 = new System.Windows.Forms.CheckBox();
            this.aff26 = new System.Windows.Forms.CheckBox();
            this.aff23 = new System.Windows.Forms.CheckBox();
            this.aff28 = new System.Windows.Forms.CheckBox();
            this.aff29 = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.aff14 = new System.Windows.Forms.CheckBox();
            this.aff17 = new System.Windows.Forms.CheckBox();
            this.aff22 = new System.Windows.Forms.CheckBox();
            this.aff12 = new System.Windows.Forms.CheckBox();
            this.aff0 = new System.Windows.Forms.CheckBox();
            this.aff10 = new System.Windows.Forms.CheckBox();
            this.aff21 = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.aff13 = new System.Windows.Forms.CheckBox();
            this.aff16 = new System.Windows.Forms.CheckBox();
            this.aff19 = new System.Windows.Forms.CheckBox();
            this.aff18 = new System.Windows.Forms.CheckBox();
            this.aff11 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.aff9 = new System.Windows.Forms.CheckBox();
            this.aff24 = new System.Windows.Forms.CheckBox();
            this.aff20 = new System.Windows.Forms.CheckBox();
            this.aff1 = new System.Windows.Forms.CheckBox();
            this.aff27 = new System.Windows.Forms.CheckBox();
            this.aff30 = new System.Windows.Forms.CheckBox();
            this.aff7 = new System.Windows.Forms.CheckBox();
            this.aff6 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.aff15 = new System.Windows.Forms.CheckBox();
            this.aff25 = new System.Windows.Forms.CheckBox();
            this.aff3 = new System.Windows.Forms.CheckBox();
            this.tab_resistenze = new System.Windows.Forms.TabPage();
            this.val16 = new System.Windows.Forms.NumericUpDown();
            this.val15 = new System.Windows.Forms.NumericUpDown();
            this.val14 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.list_suscept = new System.Windows.Forms.CheckedListBox();
            this.list_resistances = new System.Windows.Forms.CheckedListBox();
            this.list_immunities = new System.Windows.Forms.CheckedListBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tab_long = new System.Windows.Forms.TabPage();
            this.tab_desc = new System.Windows.Forms.TabPage();
            this.memo_desc = new HandofGod.MudlikeRichTextBox();
            this.tab_sounds = new System.Windows.Forms.TabPage();
            this.memo_sound_adjacent = new HandofGod.MudlikeRichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.memo_sound_sameroom = new HandofGod.MudlikeRichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.tab_gemsfame = new System.Windows.Forms.TabPage();
            this.spin_fame = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.gem_dice3 = new System.Windows.Forms.TextBox();
            this.gem_dice2 = new System.Windows.Forms.TextBox();
            this.gem_dice1 = new System.Windows.Forms.TextBox();
            this.gem_dice0 = new System.Windows.Forms.TextBox();
            this.gem_perc3 = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.gem_perc2 = new System.Windows.Forms.NumericUpDown();
            this.label42 = new System.Windows.Forms.Label();
            this.gem_perc1 = new System.Windows.Forms.NumericUpDown();
            this.label39 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.gem_perc0 = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.tab_talents = new System.Windows.Forms.TabPage();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.spin_epic14 = new System.Windows.Forms.NumericUpDown();
            this.spin_epic13 = new System.Windows.Forms.NumericUpDown();
            this.spin_epic12 = new System.Windows.Forms.NumericUpDown();
            this.label49 = new System.Windows.Forms.Label();
            this.spin_epic11 = new System.Windows.Forms.NumericUpDown();
            this.label50 = new System.Windows.Forms.Label();
            this.spin_epic10 = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.spin_epic9 = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.spin_epic8 = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.spin_epic7 = new System.Windows.Forms.NumericUpDown();
            this.spin_epic6 = new System.Windows.Forms.NumericUpDown();
            this.spin_epic5 = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.spin_epic4 = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.spin_epic3 = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.spin_epic2 = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.spin_epic1 = new System.Windows.Forms.NumericUpDown();
            this.tab_dialogs = new System.Windows.Forms.TabPage();
            this.btneditA = new System.Windows.Forms.Button();
            this.btndelA = new System.Windows.Forms.Button();
            this.btnaddA = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.list_dialog_questions = new HandofGod.HoGListView();
            this.list_dialog_answers = new HandofGod.HoGListView();
            this.btneditQ = new System.Windows.Forms.Button();
            this.btndelQ = new System.Windows.Forms.Button();
            this.btnaddQ = new System.Windows.Forms.Button();
            this.gaugecharcounter = new HandofGod.CharCounterProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.spin_vnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val5)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tab_acts.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tab_affects.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tab_resistenze.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.val16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.val14)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tab_long.SuspendLayout();
            this.tab_desc.SuspendLayout();
            this.tab_sounds.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tab_gemsfame.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spin_fame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc0)).BeginInit();
            this.tab_talents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic1)).BeginInit();
            this.tab_dialogs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // spin_vnum
            // 
            this.spin_vnum.Location = new System.Drawing.Point(83, 6);
            // 
            // lblvnum
            // 
            this.lblvnum.Location = new System.Drawing.Point(38, 8);
            // 
            // btnapply
            // 
            this.btnapply.Location = new System.Drawing.Point(481, 531);
            // 
            // btnrestore
            // 
            this.btnrestore.Location = new System.Drawing.Point(562, 531);
            // 
            // btnprev
            // 
            this.btnprev.Location = new System.Drawing.Point(677, 531);
            // 
            // btnnext
            // 
            this.btnnext.Location = new System.Drawing.Point(710, 531);
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(93, 531);
            // 
            // btnok
            // 
            this.btnok.Location = new System.Drawing.Point(12, 531);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Short Desc:";
            // 
            // edt_shortdesc
            // 
            this.edt_shortdesc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.edt_shortdesc.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.edt_shortdesc.DetectUrls = false;
            this.edt_shortdesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.edt_shortdesc.Location = new System.Drawing.Point(83, 32);
            this.edt_shortdesc.Multiline = false;
            this.edt_shortdesc.Name = "edt_shortdesc";
            this.edt_shortdesc.Size = new System.Drawing.Size(386, 20);
            this.edt_shortdesc.TabIndex = 2;
            this.edt_shortdesc.Text = "";
            this.edt_shortdesc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(182, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Keys: ";
            // 
            // edt_keys
            // 
            this.edt_keys.Location = new System.Drawing.Point(224, 6);
            this.edt_keys.Name = "edt_keys";
            this.edt_keys.Size = new System.Drawing.Size(228, 20);
            this.edt_keys.TabIndex = 1;
            this.edt_keys.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // memo_longdesc
            // 
            this.memo_longdesc.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.memo_longdesc.DetectUrls = false;
            this.memo_longdesc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memo_longdesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.memo_longdesc.Location = new System.Drawing.Point(0, 0);
            this.memo_longdesc.Name = "memo_longdesc";
            this.memo_longdesc.Size = new System.Drawing.Size(463, 253);
            this.memo_longdesc.TabIndex = 3;
            this.memo_longdesc.Text = "";
            this.memo_longdesc.WordWrap = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(483, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Tipo: ";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(475, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Sesso: ";
            // 
            // val0
            // 
            this.val0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.val0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.val0.FormattingEnabled = true;
            this.val0.Location = new System.Drawing.Point(523, 6);
            this.val0.Name = "val0";
            this.val0.Size = new System.Drawing.Size(210, 21);
            this.val0.TabIndex = 4;
            this.val0.SelectedIndexChanged += new System.EventHandler(this.UpdateButtonsState);
            this.val0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val4
            // 
            this.val4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.val4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.val4.FormattingEnabled = true;
            this.val4.Items.AddRange(new object[] {
            "Indefinito",
            "Maschio",
            "Femmina"});
            this.val4.Location = new System.Drawing.Point(523, 32);
            this.val4.Name = "val4";
            this.val4.Size = new System.Drawing.Size(210, 21);
            this.val4.TabIndex = 5;
            this.val4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(474, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "Razza: ";
            // 
            // val9
            // 
            this.val9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.val9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.val9.FormattingEnabled = true;
            this.val9.Location = new System.Drawing.Point(523, 58);
            this.val9.Name = "val9";
            this.val9.Size = new System.Drawing.Size(210, 21);
            this.val9.TabIndex = 6;
            this.val9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "Load pos: ";
            // 
            // val11
            // 
            this.val11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.val11.FormattingEnabled = true;
            this.val11.Location = new System.Drawing.Point(83, 141);
            this.val11.Name = "val11";
            this.val11.Size = new System.Drawing.Size(169, 21);
            this.val11.TabIndex = 17;
            this.val11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val12
            // 
            this.val12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.val12.FormattingEnabled = true;
            this.val12.Location = new System.Drawing.Point(83, 168);
            this.val12.Name = "val12";
            this.val12.Size = new System.Drawing.Size(169, 21);
            this.val12.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 171);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Default pos:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(38, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 13);
            this.label10.TabIndex = 33;
            this.label10.Text = "Level: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(28, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 34;
            this.label11.Text = "Attacks: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 117);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 13);
            this.label12.TabIndex = 35;
            this.label12.Text = "Spellpower: ";
            // 
            // val2
            // 
            this.val2.Location = new System.Drawing.Point(83, 61);
            this.val2.Name = "val2";
            this.val2.Size = new System.Drawing.Size(49, 20);
            this.val2.TabIndex = 7;
            this.val2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.val2.ValueChanged += new System.EventHandler(this.val2_ValueChanged);
            this.val2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val7
            // 
            this.val7.Location = new System.Drawing.Point(83, 88);
            this.val7.Name = "val7";
            this.val7.Size = new System.Drawing.Size(49, 20);
            this.val7.TabIndex = 8;
            this.val7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val13
            // 
            this.val13.Location = new System.Drawing.Point(83, 115);
            this.val13.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.val13.Name = "val13";
            this.val13.Size = new System.Drawing.Size(49, 20);
            this.val13.TabIndex = 9;
            this.val13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(138, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 13);
            this.label13.TabIndex = 39;
            this.label13.Text = "Alignment: ";
            // 
            // val1
            // 
            this.val1.Location = new System.Drawing.Point(203, 61);
            this.val1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.val1.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.val1.Name = "val1";
            this.val1.Size = new System.Drawing.Size(49, 20);
            this.val1.TabIndex = 10;
            this.val1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val3
            // 
            this.val3.Location = new System.Drawing.Point(203, 88);
            this.val3.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.val3.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.val3.Name = "val3";
            this.val3.Size = new System.Drawing.Size(49, 20);
            this.val3.TabIndex = 11;
            this.val3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(157, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 41;
            this.label14.Text = "Armor: ";
            // 
            // val10
            // 
            this.val10.Location = new System.Drawing.Point(328, 169);
            this.val10.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.val10.Minimum = new decimal(new int[] {
            9999999,
            0,
            0,
            -2147483648});
            this.val10.Name = "val10";
            this.val10.Size = new System.Drawing.Size(124, 20);
            this.val10.TabIndex = 16;
            this.val10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(287, 171);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 43;
            this.label15.Text = "Gold: ";
            // 
            // val6
            // 
            this.val6.Location = new System.Drawing.Point(328, 61);
            this.val6.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.val6.Minimum = new decimal(new int[] {
            999999999,
            0,
            0,
            -2147483648});
            this.val6.Name = "val6";
            this.val6.Size = new System.Drawing.Size(49, 20);
            this.val6.TabIndex = 13;
            this.val6.ValueChanged += new System.EventHandler(this.val2_ValueChanged);
            this.val6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(261, 63);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 13);
            this.label16.TabIndex = 45;
            this.label16.Text = "HP Bonus: ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(153, 117);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 47;
            this.label17.Text = "Thac0: ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(262, 90);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 13);
            this.label18.TabIndex = 48;
            this.label18.Text = "XP Bonus: ";
            // 
            // val8
            // 
            this.val8.Location = new System.Drawing.Point(328, 88);
            this.val8.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.val8.Minimum = new decimal(new int[] {
            9999999,
            0,
            0,
            -2147483648});
            this.val8.Name = "val8";
            this.val8.Size = new System.Drawing.Size(124, 20);
            this.val8.TabIndex = 14;
            this.val8.ValueChanged += new System.EventHandler(this.val2_ValueChanged);
            this.val8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val5
            // 
            this.val5.Location = new System.Drawing.Point(203, 115);
            this.val5.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.val5.Minimum = new decimal(new int[] {
            30,
            0,
            0,
            -2147483648});
            this.val5.Name = "val5";
            this.val5.Size = new System.Drawing.Size(49, 20);
            this.val5.TabIndex = 12;
            this.val5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(269, 146);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 53;
            this.label20.Text = "Damage: ";
            // 
            // lblavghp
            // 
            this.lblavghp.AutoSize = true;
            this.lblavghp.Location = new System.Drawing.Point(383, 63);
            this.lblavghp.Name = "lblavghp";
            this.lblavghp.Size = new System.Drawing.Size(43, 13);
            this.lblavghp.TabIndex = 51;
            this.lblavghp.Text = "(Avg: x)";
            // 
            // lblavgxp
            // 
            this.lblavgxp.AutoSize = true;
            this.lblavgxp.Location = new System.Drawing.Point(325, 111);
            this.lblavgxp.Name = "lblavgxp";
            this.lblavgxp.Size = new System.Drawing.Size(43, 13);
            this.lblavgxp.TabIndex = 58;
            this.lblavgxp.Text = "(Avg: x)";
            // 
            // edt_damage
            // 
            this.edt_damage.Location = new System.Drawing.Point(328, 143);
            this.edt_damage.Name = "edt_damage";
            this.edt_damage.Size = new System.Drawing.Size(124, 20);
            this.edt_damage.TabIndex = 15;
            this.edt_damage.TextChanged += new System.EventHandler(this.gem_dice0_TextChanged);
            this.edt_damage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tab_acts);
            this.tabControl1.Controls.Add(this.tab_affects);
            this.tabControl1.Controls.Add(this.tab_resistenze);
            this.tabControl1.Location = new System.Drawing.Point(489, 89);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(248, 390);
            this.tabControl1.TabIndex = 20;
            // 
            // tab_acts
            // 
            this.tab_acts.BackColor = System.Drawing.SystemColors.Control;
            this.tab_acts.Controls.Add(this.groupBox4);
            this.tab_acts.Controls.Add(this.groupBox3);
            this.tab_acts.Controls.Add(this.groupBox2);
            this.tab_acts.Controls.Add(this.groupBox1);
            this.tab_acts.Location = new System.Drawing.Point(4, 22);
            this.tab_acts.Name = "tab_acts";
            this.tab_acts.Padding = new System.Windows.Forms.Padding(3);
            this.tab_acts.Size = new System.Drawing.Size(240, 364);
            this.tab_acts.TabIndex = 1;
            this.tab_acts.Text = "Acts";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.MintCream;
            this.groupBox4.Controls.Add(this.act20);
            this.groupBox4.Controls.Add(this.act13);
            this.groupBox4.Controls.Add(this.act12);
            this.groupBox4.Controls.Add(this.act10);
            this.groupBox4.Controls.Add(this.act8);
            this.groupBox4.Controls.Add(this.act9);
            this.groupBox4.Controls.Add(this.act7);
            this.groupBox4.Controls.Add(this.act4);
            this.groupBox4.Controls.Add(this.act2);
            this.groupBox4.Controls.Add(this.act15);
            this.groupBox4.Controls.Add(this.act5);
            this.groupBox4.Location = new System.Drawing.Point(122, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(112, 209);
            this.groupBox4.TabIndex = 53;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Comportamento";
            // 
            // act20
            // 
            this.act20.Location = new System.Drawing.Point(9, 183);
            this.act20.Name = "act20";
            this.act20.Size = new System.Drawing.Size(110, 17);
            this.act20.TabIndex = 58;
            this.act20.Text = "greet";
            this.act20.UseVisualStyleBackColor = true;
            // 
            // act13
            // 
            this.act13.Location = new System.Drawing.Point(9, 166);
            this.act13.Name = "act13";
            this.act13.Size = new System.Drawing.Size(110, 17);
            this.act13.TabIndex = 57;
            this.act13.Text = "deadly";
            this.act13.UseVisualStyleBackColor = true;
            // 
            // act12
            // 
            this.act12.Location = new System.Drawing.Point(9, 149);
            this.act12.Name = "act12";
            this.act12.Size = new System.Drawing.Size(110, 17);
            this.act12.TabIndex = 56;
            this.act12.Text = "hunting";
            this.act12.UseVisualStyleBackColor = true;
            // 
            // act10
            // 
            this.act10.Location = new System.Drawing.Point(9, 132);
            this.act10.Name = "act10";
            this.act10.Size = new System.Drawing.Size(110, 17);
            this.act10.TabIndex = 55;
            this.act10.Text = "afraid";
            this.act10.UseVisualStyleBackColor = true;
            // 
            // act8
            // 
            this.act8.Location = new System.Drawing.Point(9, 116);
            this.act8.Name = "act8";
            this.act8.Size = new System.Drawing.Size(110, 17);
            this.act8.TabIndex = 54;
            this.act8.Text = "annoying";
            this.act8.UseVisualStyleBackColor = true;
            // 
            // act9
            // 
            this.act9.Location = new System.Drawing.Point(9, 99);
            this.act9.Name = "act9";
            this.act9.Size = new System.Drawing.Size(110, 17);
            this.act9.TabIndex = 53;
            this.act9.Text = "hateful";
            this.act9.UseVisualStyleBackColor = true;
            // 
            // act7
            // 
            this.act7.Location = new System.Drawing.Point(9, 83);
            this.act7.Name = "act7";
            this.act7.Size = new System.Drawing.Size(110, 17);
            this.act7.TabIndex = 52;
            this.act7.Text = "wimpy";
            this.act7.UseVisualStyleBackColor = true;
            this.act7.CheckedChanged += new System.EventHandler(this.val2_ValueChanged);
            // 
            // act4
            // 
            this.act4.Location = new System.Drawing.Point(9, 67);
            this.act4.Name = "act4";
            this.act4.Size = new System.Drawing.Size(110, 17);
            this.act4.TabIndex = 51;
            this.act4.Text = "nice-th";
            this.act4.UseVisualStyleBackColor = true;
            // 
            // act2
            // 
            this.act2.Location = new System.Drawing.Point(9, 51);
            this.act2.Name = "act2";
            this.act2.Size = new System.Drawing.Size(110, 17);
            this.act2.TabIndex = 50;
            this.act2.Text = "scave";
            this.act2.UseVisualStyleBackColor = true;
            // 
            // act15
            // 
            this.act15.Location = new System.Drawing.Point(9, 35);
            this.act15.Name = "act15";
            this.act15.Size = new System.Drawing.Size(110, 17);
            this.act15.TabIndex = 49;
            this.act15.Text = "meta-aggr";
            this.act15.UseVisualStyleBackColor = true;
            this.act15.CheckedChanged += new System.EventHandler(this.val2_ValueChanged);
            // 
            // act5
            // 
            this.act5.Location = new System.Drawing.Point(9, 19);
            this.act5.Name = "act5";
            this.act5.Size = new System.Drawing.Size(110, 17);
            this.act5.TabIndex = 48;
            this.act5.Text = "aggr";
            this.act5.UseVisualStyleBackColor = true;
            this.act5.CheckedChanged += new System.EventHandler(this.val2_ValueChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Lavender;
            this.groupBox3.Controls.Add(this.act19);
            this.groupBox3.Controls.Add(this.act11);
            this.groupBox3.Controls.Add(this.act3);
            this.groupBox3.Controls.Add(this.act18);
            this.groupBox3.Controls.Add(this.act17);
            this.groupBox3.Controls.Add(this.act16);
            this.groupBox3.Controls.Add(this.act14);
            this.groupBox3.Location = new System.Drawing.Point(122, 222);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(112, 136);
            this.groupBox3.TabIndex = 52;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Altro";
            // 
            // act19
            // 
            this.act19.Location = new System.Drawing.Point(9, 115);
            this.act19.Name = "act19";
            this.act19.Size = new System.Drawing.Size(90, 17);
            this.act19.TabIndex = 56;
            this.act19.Text = "script";
            this.act19.UseVisualStyleBackColor = true;
            // 
            // act11
            // 
            this.act11.Location = new System.Drawing.Point(9, 99);
            this.act11.Name = "act11";
            this.act11.Size = new System.Drawing.Size(90, 17);
            this.act11.TabIndex = 55;
            this.act11.Text = "immortal";
            this.act11.UseVisualStyleBackColor = true;
            // 
            // act3
            // 
            this.act3.Location = new System.Drawing.Point(9, 83);
            this.act3.Name = "act3";
            this.act3.Size = new System.Drawing.Size(90, 17);
            this.act3.TabIndex = 54;
            this.act3.Text = "isnpc";
            this.act3.UseVisualStyleBackColor = true;
            // 
            // act18
            // 
            this.act18.Location = new System.Drawing.Point(9, 67);
            this.act18.Name = "act18";
            this.act18.Size = new System.Drawing.Size(90, 17);
            this.act18.TabIndex = 53;
            this.act18.Text = "huge";
            this.act18.UseVisualStyleBackColor = true;
            // 
            // act17
            // 
            this.act17.Location = new System.Drawing.Point(9, 51);
            this.act17.Name = "act17";
            this.act17.Size = new System.Drawing.Size(90, 17);
            this.act17.TabIndex = 52;
            this.act17.Text = "illusion";
            this.act17.UseVisualStyleBackColor = true;
            // 
            // act16
            // 
            this.act16.Location = new System.Drawing.Point(9, 35);
            this.act16.Name = "act16";
            this.act16.Size = new System.Drawing.Size(90, 17);
            this.act16.TabIndex = 51;
            this.act16.Text = "guardian";
            this.act16.UseVisualStyleBackColor = true;
            // 
            // act14
            // 
            this.act14.Location = new System.Drawing.Point(9, 19);
            this.act14.Name = "act14";
            this.act14.Size = new System.Drawing.Size(90, 17);
            this.act14.TabIndex = 50;
            this.act14.Text = "poly";
            this.act14.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.AliceBlue;
            this.groupBox2.Controls.Add(this.act6);
            this.groupBox2.Controls.Add(this.act1);
            this.groupBox2.Controls.Add(this.act0);
            this.groupBox2.Location = new System.Drawing.Point(6, 222);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(108, 136);
            this.groupBox2.TabIndex = 51;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Movimento";
            // 
            // act6
            // 
            this.act6.Location = new System.Drawing.Point(7, 51);
            this.act6.Name = "act6";
            this.act6.Size = new System.Drawing.Size(90, 17);
            this.act6.TabIndex = 42;
            this.act6.Text = "stay zone";
            this.act6.UseVisualStyleBackColor = true;
            // 
            // act1
            // 
            this.act1.Location = new System.Drawing.Point(7, 35);
            this.act1.Name = "act1";
            this.act1.Size = new System.Drawing.Size(90, 17);
            this.act1.TabIndex = 41;
            this.act1.Text = "sentinel";
            this.act1.UseVisualStyleBackColor = true;
            // 
            // act0
            // 
            this.act0.Location = new System.Drawing.Point(7, 19);
            this.act0.Name = "act0";
            this.act0.Size = new System.Drawing.Size(90, 17);
            this.act0.TabIndex = 40;
            this.act0.Text = "immobile";
            this.act0.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Honeydew;
            this.groupBox1.Controls.Add(this.act31);
            this.groupBox1.Controls.Add(this.act30);
            this.groupBox1.Controls.Add(this.act29);
            this.groupBox1.Controls.Add(this.act28);
            this.groupBox1.Controls.Add(this.act27);
            this.groupBox1.Controls.Add(this.act26);
            this.groupBox1.Controls.Add(this.act25);
            this.groupBox1.Controls.Add(this.act24);
            this.groupBox1.Controls.Add(this.act23);
            this.groupBox1.Controls.Add(this.act22);
            this.groupBox1.Controls.Add(this.act21);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(108, 209);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "IA";
            // 
            // act31
            // 
            this.act31.Location = new System.Drawing.Point(7, 182);
            this.act31.Name = "act31";
            this.act31.Size = new System.Drawing.Size(90, 17);
            this.act31.TabIndex = 35;
            this.act31.Text = "archer";
            this.act31.UseVisualStyleBackColor = true;
            // 
            // act30
            // 
            this.act30.Location = new System.Drawing.Point(7, 166);
            this.act30.Name = "act30";
            this.act30.Size = new System.Drawing.Size(90, 17);
            this.act30.TabIndex = 34;
            this.act30.Text = "ps";
            this.act30.UseVisualStyleBackColor = true;
            // 
            // act29
            // 
            this.act29.Location = new System.Drawing.Point(7, 149);
            this.act29.Name = "act29";
            this.act29.Size = new System.Drawing.Size(90, 17);
            this.act29.TabIndex = 33;
            this.act29.Text = "ra";
            this.act29.UseVisualStyleBackColor = true;
            // 
            // act28
            // 
            this.act28.Location = new System.Drawing.Point(7, 132);
            this.act28.Name = "act28";
            this.act28.Size = new System.Drawing.Size(90, 17);
            this.act28.TabIndex = 32;
            this.act28.Text = "pa";
            this.act28.UseVisualStyleBackColor = true;
            // 
            // act27
            // 
            this.act27.Location = new System.Drawing.Point(7, 116);
            this.act27.Name = "act27";
            this.act27.Size = new System.Drawing.Size(90, 17);
            this.act27.TabIndex = 31;
            this.act27.Text = "ba";
            this.act27.UseVisualStyleBackColor = true;
            // 
            // act26
            // 
            this.act26.Location = new System.Drawing.Point(7, 99);
            this.act26.Name = "act26";
            this.act26.Size = new System.Drawing.Size(90, 17);
            this.act26.TabIndex = 30;
            this.act26.Text = "mo";
            this.act26.UseVisualStyleBackColor = true;
            // 
            // act25
            // 
            this.act25.Location = new System.Drawing.Point(7, 83);
            this.act25.Name = "act25";
            this.act25.Size = new System.Drawing.Size(90, 17);
            this.act25.TabIndex = 29;
            this.act25.Text = "dr";
            this.act25.UseVisualStyleBackColor = true;
            // 
            // act24
            // 
            this.act24.Location = new System.Drawing.Point(7, 67);
            this.act24.Name = "act24";
            this.act24.Size = new System.Drawing.Size(90, 17);
            this.act24.TabIndex = 28;
            this.act24.Text = "th";
            this.act24.UseVisualStyleBackColor = true;
            // 
            // act23
            // 
            this.act23.Location = new System.Drawing.Point(7, 51);
            this.act23.Name = "act23";
            this.act23.Size = new System.Drawing.Size(90, 17);
            this.act23.TabIndex = 27;
            this.act23.Text = "cl";
            this.act23.UseVisualStyleBackColor = true;
            // 
            // act22
            // 
            this.act22.Location = new System.Drawing.Point(7, 35);
            this.act22.Name = "act22";
            this.act22.Size = new System.Drawing.Size(90, 17);
            this.act22.TabIndex = 26;
            this.act22.Text = "wa";
            this.act22.UseVisualStyleBackColor = true;
            // 
            // act21
            // 
            this.act21.Location = new System.Drawing.Point(7, 19);
            this.act21.Name = "act21";
            this.act21.Size = new System.Drawing.Size(90, 17);
            this.act21.TabIndex = 25;
            this.act21.Text = "mu";
            this.act21.UseVisualStyleBackColor = false;
            // 
            // tab_affects
            // 
            this.tab_affects.BackColor = System.Drawing.SystemColors.Control;
            this.tab_affects.Controls.Add(this.groupBox9);
            this.tab_affects.Controls.Add(this.groupBox8);
            this.tab_affects.Controls.Add(this.groupBox7);
            this.tab_affects.Controls.Add(this.groupBox6);
            this.tab_affects.Controls.Add(this.groupBox5);
            this.tab_affects.Location = new System.Drawing.Point(4, 22);
            this.tab_affects.Name = "tab_affects";
            this.tab_affects.Size = new System.Drawing.Size(240, 364);
            this.tab_affects.TabIndex = 2;
            this.tab_affects.Text = "Affects";
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox9.Controls.Add(this.aff8);
            this.groupBox9.Controls.Add(this.aff4);
            this.groupBox9.Controls.Add(this.aff2);
            this.groupBox9.Controls.Add(this.aff5);
            this.groupBox9.Controls.Add(this.aff26);
            this.groupBox9.Controls.Add(this.aff23);
            this.groupBox9.Controls.Add(this.aff28);
            this.groupBox9.Controls.Add(this.aff29);
            this.groupBox9.Location = new System.Drawing.Point(131, 164);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(98, 194);
            this.groupBox9.TabIndex = 40;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Useless";
            // 
            // aff8
            // 
            this.aff8.Location = new System.Drawing.Point(7, 133);
            this.aff8.Name = "aff8";
            this.aff8.Size = new System.Drawing.Size(90, 17);
            this.aff8.TabIndex = 51;
            this.aff8.Text = "dragon ride";
            this.aff8.UseVisualStyleBackColor = true;
            // 
            // aff4
            // 
            this.aff4.Location = new System.Drawing.Point(7, 116);
            this.aff4.Name = "aff4";
            this.aff4.Size = new System.Drawing.Size(90, 17);
            this.aff4.TabIndex = 50;
            this.aff4.Text = "detect magic";
            this.aff4.UseVisualStyleBackColor = true;
            // 
            // aff2
            // 
            this.aff2.Location = new System.Drawing.Point(7, 99);
            this.aff2.Name = "aff2";
            this.aff2.Size = new System.Drawing.Size(90, 17);
            this.aff2.TabIndex = 49;
            this.aff2.Text = "detect evil";
            this.aff2.UseVisualStyleBackColor = true;
            // 
            // aff5
            // 
            this.aff5.Location = new System.Drawing.Point(7, 83);
            this.aff5.Name = "aff5";
            this.aff5.Size = new System.Drawing.Size(90, 17);
            this.aff5.TabIndex = 48;
            this.aff5.Text = "sense life";
            this.aff5.UseVisualStyleBackColor = true;
            // 
            // aff26
            // 
            this.aff26.Location = new System.Drawing.Point(7, 67);
            this.aff26.Name = "aff26";
            this.aff26.Size = new System.Drawing.Size(90, 17);
            this.aff26.TabIndex = 47;
            this.aff26.Text = "scrying";
            this.aff26.UseVisualStyleBackColor = true;
            // 
            // aff23
            // 
            this.aff23.Location = new System.Drawing.Point(7, 51);
            this.aff23.Name = "aff23";
            this.aff23.Size = new System.Drawing.Size(90, 17);
            this.aff23.TabIndex = 46;
            this.aff23.Text = "follower";
            this.aff23.UseVisualStyleBackColor = true;
            // 
            // aff28
            // 
            this.aff28.Location = new System.Drawing.Point(7, 35);
            this.aff28.Name = "aff28";
            this.aff28.Size = new System.Drawing.Size(90, 17);
            this.aff28.TabIndex = 45;
            this.aff28.Text = "grouped";
            this.aff28.UseVisualStyleBackColor = true;
            // 
            // aff29
            // 
            this.aff29.Location = new System.Drawing.Point(7, 19);
            this.aff29.Name = "aff29";
            this.aff29.Size = new System.Drawing.Size(90, 17);
            this.aff29.TabIndex = 44;
            this.aff29.Text = "telepat";
            this.aff29.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.PapayaWhip;
            this.groupBox8.Controls.Add(this.aff14);
            this.groupBox8.Controls.Add(this.aff17);
            this.groupBox8.Controls.Add(this.aff22);
            this.groupBox8.Controls.Add(this.aff12);
            this.groupBox8.Controls.Add(this.aff0);
            this.groupBox8.Controls.Add(this.aff10);
            this.groupBox8.Controls.Add(this.aff21);
            this.groupBox8.Location = new System.Drawing.Point(131, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(98, 152);
            this.groupBox8.TabIndex = 39;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Negativi";
            // 
            // aff14
            // 
            this.aff14.Location = new System.Drawing.Point(10, 117);
            this.aff14.Name = "aff14";
            this.aff14.Size = new System.Drawing.Size(90, 17);
            this.aff14.TabIndex = 43;
            this.aff14.Text = "paralyzed";
            this.aff14.UseVisualStyleBackColor = true;
            // 
            // aff17
            // 
            this.aff17.Location = new System.Drawing.Point(10, 100);
            this.aff17.Name = "aff17";
            this.aff17.Size = new System.Drawing.Size(90, 17);
            this.aff17.TabIndex = 42;
            this.aff17.Text = "sleep";
            this.aff17.UseVisualStyleBackColor = true;
            // 
            // aff22
            // 
            this.aff22.Location = new System.Drawing.Point(10, 83);
            this.aff22.Name = "aff22";
            this.aff22.Size = new System.Drawing.Size(90, 17);
            this.aff22.TabIndex = 41;
            this.aff22.Text = "charm";
            this.aff22.UseVisualStyleBackColor = true;
            // 
            // aff12
            // 
            this.aff12.Location = new System.Drawing.Point(10, 67);
            this.aff12.Name = "aff12";
            this.aff12.Size = new System.Drawing.Size(90, 17);
            this.aff12.TabIndex = 40;
            this.aff12.Text = "poison";
            this.aff12.UseVisualStyleBackColor = true;
            // 
            // aff0
            // 
            this.aff0.Location = new System.Drawing.Point(10, 51);
            this.aff0.Name = "aff0";
            this.aff0.Size = new System.Drawing.Size(90, 17);
            this.aff0.TabIndex = 39;
            this.aff0.Text = "blind";
            this.aff0.UseVisualStyleBackColor = true;
            // 
            // aff10
            // 
            this.aff10.Location = new System.Drawing.Point(10, 35);
            this.aff10.Name = "aff10";
            this.aff10.Size = new System.Drawing.Size(90, 17);
            this.aff10.TabIndex = 38;
            this.aff10.Text = "curse";
            this.aff10.UseVisualStyleBackColor = true;
            // 
            // aff21
            // 
            this.aff21.Location = new System.Drawing.Point(10, 19);
            this.aff21.Name = "aff21";
            this.aff21.Size = new System.Drawing.Size(90, 17);
            this.aff21.TabIndex = 37;
            this.aff21.Text = "silence";
            this.aff21.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.LightYellow;
            this.groupBox7.Controls.Add(this.aff13);
            this.groupBox7.Controls.Add(this.aff16);
            this.groupBox7.Controls.Add(this.aff19);
            this.groupBox7.Controls.Add(this.aff18);
            this.groupBox7.Controls.Add(this.aff11);
            this.groupBox7.Location = new System.Drawing.Point(6, 250);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(119, 108);
            this.groupBox7.TabIndex = 38;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Movimento";
            // 
            // aff13
            // 
            this.aff13.Location = new System.Drawing.Point(5, 83);
            this.aff13.Name = "aff13";
            this.aff13.Size = new System.Drawing.Size(90, 17);
            this.aff13.TabIndex = 36;
            this.aff13.Text = "tree travel";
            this.aff13.UseVisualStyleBackColor = true;
            // 
            // aff16
            // 
            this.aff16.Location = new System.Drawing.Point(5, 67);
            this.aff16.Name = "aff16";
            this.aff16.Size = new System.Drawing.Size(90, 17);
            this.aff16.TabIndex = 35;
            this.aff16.Text = "waterbreath";
            this.aff16.UseVisualStyleBackColor = true;
            // 
            // aff19
            // 
            this.aff19.Location = new System.Drawing.Point(5, 51);
            this.aff19.Name = "aff19";
            this.aff19.Size = new System.Drawing.Size(90, 17);
            this.aff19.TabIndex = 34;
            this.aff19.Text = "sneak";
            this.aff19.UseVisualStyleBackColor = true;
            // 
            // aff18
            // 
            this.aff18.Location = new System.Drawing.Point(5, 35);
            this.aff18.Name = "aff18";
            this.aff18.Size = new System.Drawing.Size(90, 17);
            this.aff18.TabIndex = 33;
            this.aff18.Text = "travel";
            this.aff18.UseVisualStyleBackColor = true;
            // 
            // aff11
            // 
            this.aff11.Location = new System.Drawing.Point(5, 19);
            this.aff11.Name = "aff11";
            this.aff11.Size = new System.Drawing.Size(90, 17);
            this.aff11.TabIndex = 32;
            this.aff11.Text = "fly";
            this.aff11.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Snow;
            this.groupBox6.Controls.Add(this.aff9);
            this.groupBox6.Controls.Add(this.aff24);
            this.groupBox6.Controls.Add(this.aff20);
            this.groupBox6.Controls.Add(this.aff1);
            this.groupBox6.Controls.Add(this.aff27);
            this.groupBox6.Controls.Add(this.aff30);
            this.groupBox6.Controls.Add(this.aff7);
            this.groupBox6.Controls.Add(this.aff6);
            this.groupBox6.Location = new System.Drawing.Point(5, 83);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(120, 161);
            this.groupBox6.TabIndex = 37;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Buff";
            // 
            // aff9
            // 
            this.aff9.Location = new System.Drawing.Point(5, 132);
            this.aff9.Name = "aff9";
            this.aff9.Size = new System.Drawing.Size(90, 17);
            this.aff9.TabIndex = 31;
            this.aff9.Text = "growth";
            this.aff9.UseVisualStyleBackColor = true;
            // 
            // aff24
            // 
            this.aff24.Location = new System.Drawing.Point(5, 116);
            this.aff24.Name = "aff24";
            this.aff24.Size = new System.Drawing.Size(90, 17);
            this.aff24.TabIndex = 30;
            this.aff24.Text = "protection from evil";
            this.aff24.UseVisualStyleBackColor = true;
            // 
            // aff20
            // 
            this.aff20.Location = new System.Drawing.Point(5, 99);
            this.aff20.Name = "aff20";
            this.aff20.Size = new System.Drawing.Size(90, 17);
            this.aff20.TabIndex = 29;
            this.aff20.Text = "hide";
            this.aff20.UseVisualStyleBackColor = true;
            // 
            // aff1
            // 
            this.aff1.Location = new System.Drawing.Point(5, 83);
            this.aff1.Name = "aff1";
            this.aff1.Size = new System.Drawing.Size(90, 17);
            this.aff1.TabIndex = 28;
            this.aff1.Text = "invis";
            this.aff1.UseVisualStyleBackColor = true;
            // 
            // aff27
            // 
            this.aff27.Location = new System.Drawing.Point(5, 67);
            this.aff27.Name = "aff27";
            this.aff27.Size = new System.Drawing.Size(90, 17);
            this.aff27.TabIndex = 27;
            this.aff27.Text = "fireshi";
            this.aff27.UseVisualStyleBackColor = true;
            // 
            // aff30
            // 
            this.aff30.Location = new System.Drawing.Point(5, 51);
            this.aff30.Name = "aff30";
            this.aff30.Size = new System.Drawing.Size(90, 17);
            this.aff30.TabIndex = 26;
            this.aff30.Text = "iceshi";
            this.aff30.UseVisualStyleBackColor = true;
            // 
            // aff7
            // 
            this.aff7.Location = new System.Drawing.Point(5, 35);
            this.aff7.Name = "aff7";
            this.aff7.Size = new System.Drawing.Size(90, 17);
            this.aff7.TabIndex = 25;
            this.aff7.Text = "sanc";
            this.aff7.UseVisualStyleBackColor = true;
            // 
            // aff6
            // 
            this.aff6.Location = new System.Drawing.Point(5, 19);
            this.aff6.Name = "aff6";
            this.aff6.Size = new System.Drawing.Size(90, 17);
            this.aff6.TabIndex = 24;
            this.aff6.Text = "life prote";
            this.aff6.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FloralWhite;
            this.groupBox5.Controls.Add(this.aff15);
            this.groupBox5.Controls.Add(this.aff25);
            this.groupBox5.Controls.Add(this.aff3);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(119, 71);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Vista";
            // 
            // aff15
            // 
            this.aff15.Location = new System.Drawing.Point(5, 51);
            this.aff15.Name = "aff15";
            this.aff15.Size = new System.Drawing.Size(90, 17);
            this.aff15.TabIndex = 23;
            this.aff15.Text = "infravsion";
            this.aff15.UseVisualStyleBackColor = true;
            // 
            // aff25
            // 
            this.aff25.Location = new System.Drawing.Point(5, 35);
            this.aff25.Name = "aff25";
            this.aff25.Size = new System.Drawing.Size(90, 17);
            this.aff25.TabIndex = 22;
            this.aff25.Text = "true sight";
            this.aff25.UseVisualStyleBackColor = true;
            // 
            // aff3
            // 
            this.aff3.Location = new System.Drawing.Point(5, 19);
            this.aff3.Name = "aff3";
            this.aff3.Size = new System.Drawing.Size(90, 17);
            this.aff3.TabIndex = 21;
            this.aff3.Text = "detect invis";
            this.aff3.UseVisualStyleBackColor = true;
            // 
            // tab_resistenze
            // 
            this.tab_resistenze.Controls.Add(this.val16);
            this.tab_resistenze.Controls.Add(this.val15);
            this.tab_resistenze.Controls.Add(this.val14);
            this.tab_resistenze.Controls.Add(this.label30);
            this.tab_resistenze.Controls.Add(this.label29);
            this.tab_resistenze.Controls.Add(this.label28);
            this.tab_resistenze.Controls.Add(this.label27);
            this.tab_resistenze.Controls.Add(this.label26);
            this.tab_resistenze.Controls.Add(this.label25);
            this.tab_resistenze.Controls.Add(this.list_suscept);
            this.tab_resistenze.Controls.Add(this.list_resistances);
            this.tab_resistenze.Controls.Add(this.list_immunities);
            this.tab_resistenze.Location = new System.Drawing.Point(4, 22);
            this.tab_resistenze.Name = "tab_resistenze";
            this.tab_resistenze.Padding = new System.Windows.Forms.Padding(3);
            this.tab_resistenze.Size = new System.Drawing.Size(240, 364);
            this.tab_resistenze.TabIndex = 0;
            this.tab_resistenze.Text = "Resistenze";
            this.tab_resistenze.UseVisualStyleBackColor = true;
            // 
            // val16
            // 
            this.val16.Location = new System.Drawing.Point(160, 338);
            this.val16.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.val16.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.val16.Name = "val16";
            this.val16.Size = new System.Drawing.Size(59, 20);
            this.val16.TabIndex = 26;
            this.val16.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val15
            // 
            this.val15.Location = new System.Drawing.Point(82, 338);
            this.val15.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.val15.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.val15.Name = "val15";
            this.val15.Size = new System.Drawing.Size(59, 20);
            this.val15.TabIndex = 25;
            this.val15.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // val14
            // 
            this.val14.Location = new System.Drawing.Point(6, 338);
            this.val14.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.val14.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.val14.Name = "val14";
            this.val14.Size = new System.Drawing.Size(59, 20);
            this.val14.TabIndex = 24;
            this.val14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(157, 324);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 13);
            this.label30.TabIndex = 8;
            this.label30.Text = "Rid. Pierce: ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(79, 324);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 13);
            this.label29.TabIndex = 7;
            this.label29.Text = "Rid. Slash:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 324);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 13);
            this.label28.TabIndex = 6;
            this.label28.Text = "Rid. Blunt: ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(145, 8);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 13);
            this.label27.TabIndex = 5;
            this.label27.Text = "Suscettibilità";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(77, 8);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 13);
            this.label26.TabIndex = 4;
            this.label26.Text = "Resistenze";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 8);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(49, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = "Immunità";
            // 
            // list_suscept
            // 
            this.list_suscept.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.list_suscept.CheckOnClick = true;
            this.list_suscept.FormattingEnabled = true;
            this.list_suscept.Items.AddRange(new object[] {
            " fire = 0;",
            " cold = 1;",
            " elec = 2;",
            " blow = 3;",
            "blunt = 4;",
            "pierce= 5;",
            "slash = 6;",
            "acid  = 7;",
            "poison= 8;",
            "drain = 9;",
            "sleep = 10;",
            "charm = 11;",
            "hold  = 12;",
            "nonmag= 13;",
            "plus1 = 14;",
            "plus2 = 15;",
            "plus3 = 16;",
            "plus4 = 17;"});
            this.list_suscept.Location = new System.Drawing.Point(160, 32);
            this.list_suscept.Name = "list_suscept";
            this.list_suscept.Size = new System.Drawing.Size(73, 289);
            this.list_suscept.TabIndex = 23;
            this.list_suscept.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // list_resistances
            // 
            this.list_resistances.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.list_resistances.CheckOnClick = true;
            this.list_resistances.FormattingEnabled = true;
            this.list_resistances.Items.AddRange(new object[] {
            " fire = 0;",
            " cold = 1;",
            " elec = 2;",
            " blow = 3;",
            "blunt = 4;",
            "pierce= 5;",
            "slash = 6;",
            "acid  = 7;",
            "poison= 8;",
            "drain = 9;",
            "sleep = 10;",
            "charm = 11;",
            "hold  = 12;",
            "nonmag= 13;",
            "plus1 = 14;",
            "plus2 = 15;",
            "plus3 = 16;",
            "plus4 = 17;"});
            this.list_resistances.Location = new System.Drawing.Point(82, 32);
            this.list_resistances.Name = "list_resistances";
            this.list_resistances.Size = new System.Drawing.Size(73, 289);
            this.list_resistances.TabIndex = 22;
            this.list_resistances.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // list_immunities
            // 
            this.list_immunities.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.list_immunities.CheckOnClick = true;
            this.list_immunities.FormattingEnabled = true;
            this.list_immunities.Items.AddRange(new object[] {
            " fire = 0;",
            " cold = 1;",
            " elec = 2;",
            " blow = 3;",
            "blunt = 4;",
            "pierce= 5;",
            "slash = 6;",
            "acid  = 7;",
            "poison= 8;",
            "drain = 9;",
            "sleep = 10;",
            "charm = 11;",
            "hold  = 12;",
            "nonmag= 13;",
            "plus1 = 14;",
            "plus2 = 15;",
            "plus3 = 16;",
            "plus4 = 17;"});
            this.list_immunities.Location = new System.Drawing.Point(6, 32);
            this.list_immunities.Name = "list_immunities";
            this.list_immunities.Size = new System.Drawing.Size(73, 289);
            this.list_immunities.TabIndex = 21;
            this.list_immunities.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tab_long);
            this.tabControl2.Controls.Add(this.tab_desc);
            this.tabControl2.Controls.Add(this.tab_sounds);
            this.tabControl2.Controls.Add(this.tab_gemsfame);
            this.tabControl2.Controls.Add(this.tab_talents);
            this.tabControl2.Controls.Add(this.tab_dialogs);
            this.tabControl2.Location = new System.Drawing.Point(12, 200);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(471, 279);
            this.tabControl2.TabIndex = 19;
            // 
            // tab_long
            // 
            this.tab_long.Controls.Add(this.memo_longdesc);
            this.tab_long.Location = new System.Drawing.Point(4, 22);
            this.tab_long.Name = "tab_long";
            this.tab_long.Size = new System.Drawing.Size(463, 253);
            this.tab_long.TabIndex = 5;
            this.tab_long.Text = "Long Desc";
            this.tab_long.UseVisualStyleBackColor = true;
            // 
            // tab_desc
            // 
            this.tab_desc.Controls.Add(this.memo_desc);
            this.tab_desc.Location = new System.Drawing.Point(4, 22);
            this.tab_desc.Name = "tab_desc";
            this.tab_desc.Padding = new System.Windows.Forms.Padding(3);
            this.tab_desc.Size = new System.Drawing.Size(463, 253);
            this.tab_desc.TabIndex = 0;
            this.tab_desc.Text = "Mob Desc";
            this.tab_desc.UseVisualStyleBackColor = true;
            // 
            // memo_desc
            // 
            this.memo_desc.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.memo_desc.DetectUrls = false;
            this.memo_desc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memo_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.memo_desc.Location = new System.Drawing.Point(3, 3);
            this.memo_desc.Name = "memo_desc";
            this.memo_desc.Size = new System.Drawing.Size(457, 247);
            this.memo_desc.TabIndex = 1;
            this.memo_desc.Text = "";
            this.memo_desc.WordWrap = false;
            // 
            // tab_sounds
            // 
            this.tab_sounds.Controls.Add(this.memo_sound_adjacent);
            this.tab_sounds.Controls.Add(this.panel2);
            this.tab_sounds.Controls.Add(this.memo_sound_sameroom);
            this.tab_sounds.Controls.Add(this.panel1);
            this.tab_sounds.Location = new System.Drawing.Point(4, 22);
            this.tab_sounds.Name = "tab_sounds";
            this.tab_sounds.Padding = new System.Windows.Forms.Padding(3);
            this.tab_sounds.Size = new System.Drawing.Size(463, 253);
            this.tab_sounds.TabIndex = 1;
            this.tab_sounds.Text = "Suoni";
            this.tab_sounds.UseVisualStyleBackColor = true;
            // 
            // memo_sound_adjacent
            // 
            this.memo_sound_adjacent.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.memo_sound_adjacent.DetectUrls = false;
            this.memo_sound_adjacent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memo_sound_adjacent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.memo_sound_adjacent.Location = new System.Drawing.Point(3, 134);
            this.memo_sound_adjacent.Name = "memo_sound_adjacent";
            this.memo_sound_adjacent.Size = new System.Drawing.Size(457, 116);
            this.memo_sound_adjacent.TabIndex = 2;
            this.memo_sound_adjacent.Text = "";
            this.memo_sound_adjacent.WordWrap = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.label31);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 114);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(457, 20);
            this.panel2.TabIndex = 4;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(3, 4);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 13);
            this.label31.TabIndex = 1;
            this.label31.Text = "Nelle stanze adiacenti: ";
            // 
            // memo_sound_sameroom
            // 
            this.memo_sound_sameroom.DefaultCharacterColor = System.Drawing.Color.LightGray;
            this.memo_sound_sameroom.DetectUrls = false;
            this.memo_sound_sameroom.Dock = System.Windows.Forms.DockStyle.Top;
            this.memo_sound_sameroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.memo_sound_sameroom.Location = new System.Drawing.Point(3, 23);
            this.memo_sound_sameroom.Name = "memo_sound_sameroom";
            this.memo_sound_sameroom.Size = new System.Drawing.Size(457, 91);
            this.memo_sound_sameroom.TabIndex = 1;
            this.memo_sound_sameroom.Text = "";
            this.memo_sound_sameroom.WordWrap = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.label24);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(457, 20);
            this.panel1.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 4);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(104, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Nella stessa stanza: ";
            // 
            // tab_gemsfame
            // 
            this.tab_gemsfame.BackColor = System.Drawing.SystemColors.Control;
            this.tab_gemsfame.Controls.Add(this.spin_fame);
            this.tab_gemsfame.Controls.Add(this.label33);
            this.tab_gemsfame.Controls.Add(this.gem_dice3);
            this.tab_gemsfame.Controls.Add(this.gem_dice2);
            this.tab_gemsfame.Controls.Add(this.gem_dice1);
            this.tab_gemsfame.Controls.Add(this.gem_dice0);
            this.tab_gemsfame.Controls.Add(this.gem_perc3);
            this.tab_gemsfame.Controls.Add(this.label45);
            this.tab_gemsfame.Controls.Add(this.gem_perc2);
            this.tab_gemsfame.Controls.Add(this.label42);
            this.tab_gemsfame.Controls.Add(this.gem_perc1);
            this.tab_gemsfame.Controls.Add(this.label39);
            this.tab_gemsfame.Controls.Add(this.label36);
            this.tab_gemsfame.Controls.Add(this.label35);
            this.tab_gemsfame.Controls.Add(this.gem_perc0);
            this.tab_gemsfame.Controls.Add(this.label32);
            this.tab_gemsfame.Location = new System.Drawing.Point(4, 22);
            this.tab_gemsfame.Name = "tab_gemsfame";
            this.tab_gemsfame.Size = new System.Drawing.Size(463, 253);
            this.tab_gemsfame.TabIndex = 3;
            this.tab_gemsfame.Text = "Gemme e Fama";
            // 
            // spin_fame
            // 
            this.spin_fame.Location = new System.Drawing.Point(368, 21);
            this.spin_fame.Name = "spin_fame";
            this.spin_fame.Size = new System.Drawing.Size(68, 20);
            this.spin_fame.TabIndex = 68;
            this.spin_fame.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(325, 24);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(33, 13);
            this.label33.TabIndex = 105;
            this.label33.Text = "Fama";
            // 
            // gem_dice3
            // 
            this.gem_dice3.Location = new System.Drawing.Point(160, 169);
            this.gem_dice3.Name = "gem_dice3";
            this.gem_dice3.Size = new System.Drawing.Size(85, 20);
            this.gem_dice3.TabIndex = 67;
            this.gem_dice3.TextChanged += new System.EventHandler(this.gem_dice0_TextChanged);
            this.gem_dice3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // gem_dice2
            // 
            this.gem_dice2.Location = new System.Drawing.Point(160, 129);
            this.gem_dice2.Name = "gem_dice2";
            this.gem_dice2.Size = new System.Drawing.Size(85, 20);
            this.gem_dice2.TabIndex = 65;
            this.gem_dice2.TextChanged += new System.EventHandler(this.gem_dice0_TextChanged);
            this.gem_dice2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // gem_dice1
            // 
            this.gem_dice1.Location = new System.Drawing.Point(160, 89);
            this.gem_dice1.Name = "gem_dice1";
            this.gem_dice1.Size = new System.Drawing.Size(85, 20);
            this.gem_dice1.TabIndex = 63;
            this.gem_dice1.TextChanged += new System.EventHandler(this.gem_dice0_TextChanged);
            this.gem_dice1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // gem_dice0
            // 
            this.gem_dice0.Location = new System.Drawing.Point(160, 49);
            this.gem_dice0.Name = "gem_dice0";
            this.gem_dice0.Size = new System.Drawing.Size(85, 20);
            this.gem_dice0.TabIndex = 61;
            this.gem_dice0.TextChanged += new System.EventHandler(this.gem_dice0_TextChanged);
            this.gem_dice0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // gem_perc3
            // 
            this.gem_perc3.Location = new System.Drawing.Point(78, 170);
            this.gem_perc3.Name = "gem_perc3";
            this.gem_perc3.Size = new System.Drawing.Size(53, 20);
            this.gem_perc3.TabIndex = 66;
            this.gem_perc3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(14, 172);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(33, 13);
            this.label45.TabIndex = 99;
            this.label45.Text = "Zaffiri";
            // 
            // gem_perc2
            // 
            this.gem_perc2.Location = new System.Drawing.Point(78, 130);
            this.gem_perc2.Name = "gem_perc2";
            this.gem_perc2.Size = new System.Drawing.Size(53, 20);
            this.gem_perc2.TabIndex = 64;
            this.gem_perc2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(14, 132);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(37, 13);
            this.label42.TabIndex = 92;
            this.label42.Text = "Rubini";
            // 
            // gem_perc1
            // 
            this.gem_perc1.Location = new System.Drawing.Point(78, 90);
            this.gem_perc1.Name = "gem_perc1";
            this.gem_perc1.Size = new System.Drawing.Size(53, 20);
            this.gem_perc1.TabIndex = 62;
            this.gem_perc1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(14, 92);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(47, 13);
            this.label39.TabIndex = 85;
            this.label39.Text = "Smeraldi";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(177, 21);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(50, 13);
            this.label36.TabIndex = 84;
            this.label36.Text = "Quantità ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(72, 21);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(64, 13);
            this.label35.TabIndex = 83;
            this.label35.Text = "Percentuale";
            // 
            // gem_perc0
            // 
            this.gem_perc0.Location = new System.Drawing.Point(78, 50);
            this.gem_perc0.Name = "gem_perc0";
            this.gem_perc0.Size = new System.Drawing.Size(53, 20);
            this.gem_perc0.TabIndex = 60;
            this.gem_perc0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(14, 52);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 13);
            this.label32.TabIndex = 76;
            this.label32.Text = "Diamanti";
            // 
            // tab_talents
            // 
            this.tab_talents.BackColor = System.Drawing.SystemColors.Control;
            this.tab_talents.Controls.Add(this.label46);
            this.tab_talents.Controls.Add(this.label47);
            this.tab_talents.Controls.Add(this.label48);
            this.tab_talents.Controls.Add(this.spin_epic14);
            this.tab_talents.Controls.Add(this.spin_epic13);
            this.tab_talents.Controls.Add(this.spin_epic12);
            this.tab_talents.Controls.Add(this.label49);
            this.tab_talents.Controls.Add(this.spin_epic11);
            this.tab_talents.Controls.Add(this.label50);
            this.tab_talents.Controls.Add(this.spin_epic10);
            this.tab_talents.Controls.Add(this.label51);
            this.tab_talents.Controls.Add(this.spin_epic9);
            this.tab_talents.Controls.Add(this.label52);
            this.tab_talents.Controls.Add(this.spin_epic8);
            this.tab_talents.Controls.Add(this.label41);
            this.tab_talents.Controls.Add(this.label43);
            this.tab_talents.Controls.Add(this.label44);
            this.tab_talents.Controls.Add(this.spin_epic7);
            this.tab_talents.Controls.Add(this.spin_epic6);
            this.tab_talents.Controls.Add(this.spin_epic5);
            this.tab_talents.Controls.Add(this.label38);
            this.tab_talents.Controls.Add(this.spin_epic4);
            this.tab_talents.Controls.Add(this.label40);
            this.tab_talents.Controls.Add(this.spin_epic3);
            this.tab_talents.Controls.Add(this.label37);
            this.tab_talents.Controls.Add(this.spin_epic2);
            this.tab_talents.Controls.Add(this.label34);
            this.tab_talents.Controls.Add(this.spin_epic1);
            this.tab_talents.Location = new System.Drawing.Point(4, 22);
            this.tab_talents.Name = "tab_talents";
            this.tab_talents.Size = new System.Drawing.Size(463, 253);
            this.tab_talents.TabIndex = 4;
            this.tab_talents.Text = "Talenti Epici";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(236, 190);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(90, 13);
            this.label46.TabIndex = 27;
            this.label46.Text = "Backstab Focus: ";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(238, 164);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(88, 13);
            this.label47.TabIndex = 26;
            this.label47.Text = "Avoid Backstab: ";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(249, 138);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(77, 13);
            this.label48.TabIndex = 25;
            this.label48.Text = "Disarm Focus: ";
            // 
            // spin_epic14
            // 
            this.spin_epic14.Location = new System.Drawing.Point(331, 188);
            this.spin_epic14.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic14.Name = "spin_epic14";
            this.spin_epic14.Size = new System.Drawing.Size(91, 20);
            this.spin_epic14.TabIndex = 73;
            this.spin_epic14.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // spin_epic13
            // 
            this.spin_epic13.Location = new System.Drawing.Point(331, 162);
            this.spin_epic13.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic13.Name = "spin_epic13";
            this.spin_epic13.Size = new System.Drawing.Size(91, 20);
            this.spin_epic13.TabIndex = 72;
            this.spin_epic13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // spin_epic12
            // 
            this.spin_epic12.Location = new System.Drawing.Point(331, 136);
            this.spin_epic12.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic12.Name = "spin_epic12";
            this.spin_epic12.Size = new System.Drawing.Size(91, 20);
            this.spin_epic12.TabIndex = 71;
            this.spin_epic12.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(251, 112);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(75, 13);
            this.label49.TabIndex = 21;
            this.label49.Text = "Avoid Disarm: ";
            // 
            // spin_epic11
            // 
            this.spin_epic11.Location = new System.Drawing.Point(331, 110);
            this.spin_epic11.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic11.Name = "spin_epic11";
            this.spin_epic11.Size = new System.Drawing.Size(91, 20);
            this.spin_epic11.TabIndex = 70;
            this.spin_epic11.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(220, 86);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(106, 13);
            this.label50.TabIndex = 19;
            this.label50.Text = "Dispel Magic Focus: ";
            // 
            // spin_epic10
            // 
            this.spin_epic10.Location = new System.Drawing.Point(331, 84);
            this.spin_epic10.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic10.Name = "spin_epic10";
            this.spin_epic10.Size = new System.Drawing.Size(91, 20);
            this.spin_epic10.TabIndex = 69;
            this.spin_epic10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(222, 60);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(104, 13);
            this.label51.TabIndex = 17;
            this.label51.Text = "Avoid Dispel Magic: ";
            // 
            // spin_epic9
            // 
            this.spin_epic9.Location = new System.Drawing.Point(331, 58);
            this.spin_epic9.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic9.Name = "spin_epic9";
            this.spin_epic9.Size = new System.Drawing.Size(91, 20);
            this.spin_epic9.TabIndex = 68;
            this.spin_epic9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(240, 34);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(86, 13);
            this.label52.TabIndex = 15;
            this.label52.Text = "Luck of Heroes: ";
            // 
            // spin_epic8
            // 
            this.spin_epic8.Location = new System.Drawing.Point(331, 32);
            this.spin_epic8.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic8.Name = "spin_epic8";
            this.spin_epic8.Size = new System.Drawing.Size(91, 20);
            this.spin_epic8.TabIndex = 67;
            this.spin_epic8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(66, 190);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(59, 13);
            this.label41.TabIndex = 13;
            this.label41.Text = "Travelling: ";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(68, 164);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(57, 13);
            this.label43.TabIndex = 12;
            this.label43.Text = "Spellcraft: ";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(59, 138);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(66, 13);
            this.label44.TabIndex = 11;
            this.label44.Text = "Toughness: ";
            // 
            // spin_epic7
            // 
            this.spin_epic7.Location = new System.Drawing.Point(125, 188);
            this.spin_epic7.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic7.Name = "spin_epic7";
            this.spin_epic7.Size = new System.Drawing.Size(91, 20);
            this.spin_epic7.TabIndex = 66;
            this.spin_epic7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // spin_epic6
            // 
            this.spin_epic6.Location = new System.Drawing.Point(125, 162);
            this.spin_epic6.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic6.Name = "spin_epic6";
            this.spin_epic6.Size = new System.Drawing.Size(91, 20);
            this.spin_epic6.TabIndex = 65;
            this.spin_epic6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // spin_epic5
            // 
            this.spin_epic5.Location = new System.Drawing.Point(125, 136);
            this.spin_epic5.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic5.Name = "spin_epic5";
            this.spin_epic5.Size = new System.Drawing.Size(91, 20);
            this.spin_epic5.TabIndex = 64;
            this.spin_epic5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(60, 112);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(65, 13);
            this.label38.TabIndex = 7;
            this.label38.Text = "Spellpower: ";
            // 
            // spin_epic4
            // 
            this.spin_epic4.Location = new System.Drawing.Point(125, 110);
            this.spin_epic4.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic4.Name = "spin_epic4";
            this.spin_epic4.Size = new System.Drawing.Size(91, 20);
            this.spin_epic4.TabIndex = 63;
            this.spin_epic4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(14, 86);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(111, 13);
            this.label40.TabIndex = 5;
            this.label40.Text = "Pierce Specialization: ";
            // 
            // spin_epic3
            // 
            this.spin_epic3.Location = new System.Drawing.Point(125, 84);
            this.spin_epic3.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic3.Name = "spin_epic3";
            this.spin_epic3.Size = new System.Drawing.Size(91, 20);
            this.spin_epic3.TabIndex = 62;
            this.spin_epic3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(18, 60);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(107, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "Slash Specialization: ";
            // 
            // spin_epic2
            // 
            this.spin_epic2.Location = new System.Drawing.Point(125, 58);
            this.spin_epic2.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic2.Name = "spin_epic2";
            this.spin_epic2.Size = new System.Drawing.Size(91, 20);
            this.spin_epic2.TabIndex = 61;
            this.spin_epic2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(20, 34);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(105, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "Blunt Specialization: ";
            // 
            // spin_epic1
            // 
            this.spin_epic1.Location = new System.Drawing.Point(125, 32);
            this.spin_epic1.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.spin_epic1.Name = "spin_epic1";
            this.spin_epic1.Size = new System.Drawing.Size(91, 20);
            this.spin_epic1.TabIndex = 60;
            this.spin_epic1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.val7_KeyDown);
            // 
            // tab_dialogs
            // 
            this.tab_dialogs.BackColor = System.Drawing.SystemColors.Control;
            this.tab_dialogs.Controls.Add(this.btneditA);
            this.tab_dialogs.Controls.Add(this.btndelA);
            this.tab_dialogs.Controls.Add(this.btnaddA);
            this.tab_dialogs.Controls.Add(this.splitContainer1);
            this.tab_dialogs.Controls.Add(this.btneditQ);
            this.tab_dialogs.Controls.Add(this.btndelQ);
            this.tab_dialogs.Controls.Add(this.btnaddQ);
            this.tab_dialogs.Location = new System.Drawing.Point(4, 22);
            this.tab_dialogs.Name = "tab_dialogs";
            this.tab_dialogs.Size = new System.Drawing.Size(463, 253);
            this.tab_dialogs.TabIndex = 6;
            this.tab_dialogs.Text = "Dialoghi";
            // 
            // btneditA
            // 
            this.btneditA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btneditA.Location = new System.Drawing.Point(407, 185);
            this.btneditA.Name = "btneditA";
            this.btneditA.Size = new System.Drawing.Size(46, 28);
            this.btneditA.TabIndex = 13;
            this.btneditA.Text = "Edit A";
            this.btneditA.UseVisualStyleBackColor = true;
            this.btneditA.Click += new System.EventHandler(this.btnedit_dialog_Click);
            // 
            // btndelA
            // 
            this.btndelA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btndelA.Location = new System.Drawing.Point(407, 219);
            this.btndelA.Name = "btndelA";
            this.btndelA.Size = new System.Drawing.Size(46, 28);
            this.btndelA.TabIndex = 14;
            this.btndelA.Text = "Del A";
            this.btndelA.UseVisualStyleBackColor = true;
            this.btndelA.Click += new System.EventHandler(this.btndel_dialog_Click);
            // 
            // btnaddA
            // 
            this.btnaddA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnaddA.Location = new System.Drawing.Point(407, 151);
            this.btnaddA.Name = "btnaddA";
            this.btnaddA.Size = new System.Drawing.Size(46, 28);
            this.btnaddA.TabIndex = 12;
            this.btnaddA.Text = "Add A";
            this.btnaddA.UseVisualStyleBackColor = true;
            this.btnaddA.Click += new System.EventHandler(this.btnadd_dialog_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(2, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.list_dialog_questions);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.list_dialog_answers);
            this.splitContainer1.Size = new System.Drawing.Size(387, 253);
            this.splitContainer1.SplitterDistance = 129;
            this.splitContainer1.TabIndex = 11;
            // 
            // list_dialog_questions
            // 
            this.list_dialog_questions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_dialog_questions.Filter = "";
            this.list_dialog_questions.FullRowSelect = true;
            this.list_dialog_questions.GridLines = true;
            this.list_dialog_questions.HideSelection = false;
            this.list_dialog_questions.Location = new System.Drawing.Point(0, 0);
            this.list_dialog_questions.MultiSelect = false;
            this.list_dialog_questions.Name = "list_dialog_questions";
            this.list_dialog_questions.Size = new System.Drawing.Size(387, 129);
            this.list_dialog_questions.TabIndex = 0;
            this.list_dialog_questions.UseCompatibleStateImageBehavior = false;
            this.list_dialog_questions.View = System.Windows.Forms.View.Details;
            this.list_dialog_questions.SelectedIndexChanged += new System.EventHandler(this.list_dialog_questions_SelectedIndexChanged);
            this.list_dialog_questions.DoubleClick += new System.EventHandler(this.list_dialog_questions_DoubleClick);
            // 
            // list_dialog_answers
            // 
            this.list_dialog_answers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_dialog_answers.Filter = "";
            this.list_dialog_answers.FullRowSelect = true;
            this.list_dialog_answers.GridLines = true;
            this.list_dialog_answers.HideSelection = false;
            this.list_dialog_answers.Location = new System.Drawing.Point(0, 0);
            this.list_dialog_answers.MultiSelect = false;
            this.list_dialog_answers.Name = "list_dialog_answers";
            this.list_dialog_answers.Size = new System.Drawing.Size(387, 120);
            this.list_dialog_answers.TabIndex = 1;
            this.list_dialog_answers.UseCompatibleStateImageBehavior = false;
            this.list_dialog_answers.View = System.Windows.Forms.View.Details;
            this.list_dialog_answers.DoubleClick += new System.EventHandler(this.list_dialog_questions_DoubleClick);
            // 
            // btneditQ
            // 
            this.btneditQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btneditQ.Location = new System.Drawing.Point(407, 45);
            this.btneditQ.Name = "btneditQ";
            this.btneditQ.Size = new System.Drawing.Size(46, 28);
            this.btneditQ.TabIndex = 9;
            this.btneditQ.Text = "Edit Q";
            this.btneditQ.UseVisualStyleBackColor = true;
            this.btneditQ.Click += new System.EventHandler(this.btnedit_dialog_Click);
            // 
            // btndelQ
            // 
            this.btndelQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btndelQ.Location = new System.Drawing.Point(407, 79);
            this.btndelQ.Name = "btndelQ";
            this.btndelQ.Size = new System.Drawing.Size(46, 28);
            this.btndelQ.TabIndex = 10;
            this.btndelQ.Text = "Del Q";
            this.btndelQ.UseVisualStyleBackColor = true;
            this.btndelQ.Click += new System.EventHandler(this.btndel_dialog_Click);
            // 
            // btnaddQ
            // 
            this.btnaddQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnaddQ.Location = new System.Drawing.Point(407, 11);
            this.btnaddQ.Name = "btnaddQ";
            this.btnaddQ.Size = new System.Drawing.Size(46, 28);
            this.btnaddQ.TabIndex = 8;
            this.btnaddQ.Text = "Add Q";
            this.btnaddQ.UseVisualStyleBackColor = true;
            this.btnaddQ.Click += new System.EventHandler(this.btnadd_dialog_Click);
            // 
            // gaugecharcounter
            // 
            this.gaugecharcounter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gaugecharcounter.Location = new System.Drawing.Point(17, 478);
            this.gaugecharcounter.Name = "gaugecharcounter";
            this.gaugecharcounter.Size = new System.Drawing.Size(462, 15);
            this.gaugecharcounter.TabIndex = 73;
            // 
            // frm_Mob
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 566);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.edt_damage);
            this.Controls.Add(this.lblavgxp);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lblavghp);
            this.Controls.Add(this.val5);
            this.Controls.Add(this.val8);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.val6);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.val10);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.val3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.val1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.val13);
            this.Controls.Add(this.val7);
            this.Controls.Add(this.val2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.gaugecharcounter);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.val12);
            this.Controls.Add(this.val11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.val9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.val4);
            this.Controls.Add(this.val0);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.edt_keys);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.edt_shortdesc);
            this.MinimumSize = new System.Drawing.Size(742, 605);
            this.Name = "frm_Mob";
            this.Text = "Mob Editor";
            this.Controls.SetChildIndex(this.edt_shortdesc, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.edt_keys, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.val0, 0);
            this.Controls.SetChildIndex(this.val4, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.val9, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.val11, 0);
            this.Controls.SetChildIndex(this.val12, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.gaugecharcounter, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.val2, 0);
            this.Controls.SetChildIndex(this.val7, 0);
            this.Controls.SetChildIndex(this.val13, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.val1, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.val3, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.val10, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.val6, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.label18, 0);
            this.Controls.SetChildIndex(this.val8, 0);
            this.Controls.SetChildIndex(this.val5, 0);
            this.Controls.SetChildIndex(this.lblavghp, 0);
            this.Controls.SetChildIndex(this.label20, 0);
            this.Controls.SetChildIndex(this.lblavgxp, 0);
            this.Controls.SetChildIndex(this.edt_damage, 0);
            this.Controls.SetChildIndex(this.tabControl1, 0);
            this.Controls.SetChildIndex(this.tabControl2, 0);
            this.Controls.SetChildIndex(this.btnok, 0);
            this.Controls.SetChildIndex(this.btncancel, 0);
            this.Controls.SetChildIndex(this.btnnext, 0);
            this.Controls.SetChildIndex(this.btnprev, 0);
            this.Controls.SetChildIndex(this.btnrestore, 0);
            this.Controls.SetChildIndex(this.btnapply, 0);
            this.Controls.SetChildIndex(this.lblvnum, 0);
            this.Controls.SetChildIndex(this.spin_vnum, 0);
            ((System.ComponentModel.ISupportInitialize)(this.spin_vnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val5)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tab_acts.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tab_affects.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tab_resistenze.ResumeLayout(false);
            this.tab_resistenze.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.val16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.val14)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tab_long.ResumeLayout(false);
            this.tab_desc.ResumeLayout(false);
            this.tab_sounds.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tab_gemsfame.ResumeLayout(false);
            this.tab_gemsfame.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spin_fame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gem_perc0)).EndInit();
            this.tab_talents.ResumeLayout(false);
            this.tab_talents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spin_epic1)).EndInit();
            this.tab_dialogs.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private MudlikeRichTextBox edt_shortdesc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox edt_keys;
        private MudlikeRichTextBox memo_longdesc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox val0;
        private System.Windows.Forms.ComboBox val4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox val9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox val11;
        private System.Windows.Forms.ComboBox val12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown val2;
        private System.Windows.Forms.NumericUpDown val7;
        private System.Windows.Forms.NumericUpDown val13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown val1;
        private System.Windows.Forms.NumericUpDown val3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown val10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown val6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown val8;
        private System.Windows.Forms.NumericUpDown val5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblavghp;
        private System.Windows.Forms.Label lblavgxp;
        private System.Windows.Forms.TextBox edt_damage;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_resistenze;
        private System.Windows.Forms.TabPage tab_acts;
        private System.Windows.Forms.CheckedListBox list_immunities;
        private System.Windows.Forms.CheckedListBox list_suscept;
        private System.Windows.Forms.CheckedListBox list_resistances;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tab_affects;
        private System.Windows.Forms.NumericUpDown val16;
        private System.Windows.Forms.NumericUpDown val15;
        private System.Windows.Forms.NumericUpDown val14;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tab_desc;
        private System.Windows.Forms.TabPage tab_sounds;
        private MudlikeRichTextBox memo_desc;
        private MudlikeRichTextBox memo_sound_sameroom;
        private MudlikeRichTextBox memo_sound_adjacent;
        private System.Windows.Forms.TabPage tab_gemsfame;
        private System.Windows.Forms.TabPage tab_talents;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label24;
        private CharCounterProgressBar gaugecharcounter;
        private System.Windows.Forms.NumericUpDown gem_perc3;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.NumericUpDown gem_perc2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown gem_perc1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown gem_perc0;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox gem_dice3;
        private System.Windows.Forms.TextBox gem_dice2;
        private System.Windows.Forms.TextBox gem_dice1;
        private System.Windows.Forms.TextBox gem_dice0;
        private System.Windows.Forms.NumericUpDown spin_fame;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.NumericUpDown spin_epic14;
        private System.Windows.Forms.NumericUpDown spin_epic13;
        private System.Windows.Forms.NumericUpDown spin_epic12;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.NumericUpDown spin_epic11;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.NumericUpDown spin_epic10;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown spin_epic9;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.NumericUpDown spin_epic8;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown spin_epic7;
        private System.Windows.Forms.NumericUpDown spin_epic6;
        private System.Windows.Forms.NumericUpDown spin_epic5;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.NumericUpDown spin_epic4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.NumericUpDown spin_epic3;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown spin_epic2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown spin_epic1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox act31;
        private System.Windows.Forms.CheckBox act30;
        private System.Windows.Forms.CheckBox act29;
        private System.Windows.Forms.CheckBox act28;
        private System.Windows.Forms.CheckBox act27;
        private System.Windows.Forms.CheckBox act26;
        private System.Windows.Forms.CheckBox act25;
        private System.Windows.Forms.CheckBox act24;
        private System.Windows.Forms.CheckBox act23;
        private System.Windows.Forms.CheckBox act22;
        private System.Windows.Forms.CheckBox act21;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox act20;
        private System.Windows.Forms.CheckBox act13;
        private System.Windows.Forms.CheckBox act12;
        private System.Windows.Forms.CheckBox act10;
        private System.Windows.Forms.CheckBox act8;
        private System.Windows.Forms.CheckBox act9;
        private System.Windows.Forms.CheckBox act7;
        private System.Windows.Forms.CheckBox act4;
        private System.Windows.Forms.CheckBox act2;
        private System.Windows.Forms.CheckBox act15;
        private System.Windows.Forms.CheckBox act5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox act19;
        private System.Windows.Forms.CheckBox act11;
        private System.Windows.Forms.CheckBox act3;
        private System.Windows.Forms.CheckBox act18;
        private System.Windows.Forms.CheckBox act17;
        private System.Windows.Forms.CheckBox act16;
        private System.Windows.Forms.CheckBox act14;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox act6;
        private System.Windows.Forms.CheckBox act1;
        private System.Windows.Forms.CheckBox act0;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox aff8;
        private System.Windows.Forms.CheckBox aff4;
        private System.Windows.Forms.CheckBox aff2;
        private System.Windows.Forms.CheckBox aff5;
        private System.Windows.Forms.CheckBox aff26;
        private System.Windows.Forms.CheckBox aff23;
        private System.Windows.Forms.CheckBox aff28;
        private System.Windows.Forms.CheckBox aff29;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox aff14;
        private System.Windows.Forms.CheckBox aff17;
        private System.Windows.Forms.CheckBox aff22;
        private System.Windows.Forms.CheckBox aff12;
        private System.Windows.Forms.CheckBox aff0;
        private System.Windows.Forms.CheckBox aff10;
        private System.Windows.Forms.CheckBox aff21;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox aff13;
        private System.Windows.Forms.CheckBox aff16;
        private System.Windows.Forms.CheckBox aff19;
        private System.Windows.Forms.CheckBox aff18;
        private System.Windows.Forms.CheckBox aff11;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox aff9;
        private System.Windows.Forms.CheckBox aff24;
        private System.Windows.Forms.CheckBox aff20;
        private System.Windows.Forms.CheckBox aff1;
        private System.Windows.Forms.CheckBox aff27;
        private System.Windows.Forms.CheckBox aff30;
        private System.Windows.Forms.CheckBox aff7;
        private System.Windows.Forms.CheckBox aff6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox aff15;
        private System.Windows.Forms.CheckBox aff25;
        private System.Windows.Forms.CheckBox aff3;
        private System.Windows.Forms.TabPage tab_long;
        private System.Windows.Forms.TabPage tab_dialogs;
        private System.Windows.Forms.Button btneditQ;
        private System.Windows.Forms.Button btndelQ;
        private System.Windows.Forms.Button btnaddQ;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private HoGListView list_dialog_questions;
        private HoGListView list_dialog_answers;
        private System.Windows.Forms.Button btneditA;
        private System.Windows.Forms.Button btndelA;
        private System.Windows.Forms.Button btnaddA;
    }
}